package com.enation.app.shop.component.payment.plugin.alipay.sdk34.api.response;


import com.enation.app.shop.component.payment.plugin.alipay.sdk34.api.AlipayResponse;

/**
 * ALIPAY API: alipay.eco.cplife.repair.status.update response.
 * 
 * @author auto create
 * @since 1.0, 2016-07-14 19:53:30
 */
public class AlipayEcoCplifeRepairStatusUpdateResponse extends AlipayResponse {

	private static final long serialVersionUID = 1244893957489512547L;

	

	

}
