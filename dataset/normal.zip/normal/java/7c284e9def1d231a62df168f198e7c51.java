package com.enation.app.shop.component.bonus;

import org.springframework.stereotype.Component;

import com.enation.framework.component.IComponent;

/**
 * 红包组件
 * @author kingapex
 *2013-9-20上午10:45:32
 */
@Component
public class BonusComponent implements IComponent {

	@Override
	public void install() {

	}

	@Override
	public void unInstall() {

	}

}
