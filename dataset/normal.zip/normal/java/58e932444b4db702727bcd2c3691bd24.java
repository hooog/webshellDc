package com.jspxcms.ext.repository.impl;

import com.jspxcms.ext.repository.plus.QuestionItemRecDaoPlus;

public class QuestionItemRecDaoImpl implements QuestionItemRecDaoPlus {

}
