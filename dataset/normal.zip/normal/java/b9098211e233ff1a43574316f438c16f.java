package com.jspxcms.ext.listener;

/**
 * FrendlinkTypeDeleteListener
 * 
 * @author liufang
 * 
 */
public interface FriendlinkTypeDeleteListener {
	public void preFriendlinkTypeDelete(Integer[] ids);
}
