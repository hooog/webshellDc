/*
 * Copyright (C), 2002-2015, 苏宁易购电子商务有限公司
 * FileName: User_ListDaoImpl.java
 * Author:   15071335
 * Date:     2015年7月24日 下午2:02:19
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.suning.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.suning.dao.IUser_ListDao;
import com.suning.framework.dal.client.support.DefaultDalClient;
import com.suning.pojo.User_List;

/**
 * 〈一句话功能简述〉<br>
 * 〈功能详细描述〉
 *
 * @author 15071335
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class User_ListDaoImpl implements IUser_ListDao {

	@Autowired
	private DefaultDalClient dalClient;

	public DefaultDalClient getDalClient() {
		return dalClient;
	}

	public void setDalClient(DefaultDalClient dalClient) {
		this.dalClient = dalClient;
	}

	public void addUser(User_List user_List) {
		int result = dalClient.execute("user_list.addUser", user_List);
		System.out.println("user_list.addUser=" + result);
	}

	public User_List getUserBySn_User_id(String sn_user_id) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("sn_user_id", sn_user_id);
		return dalClient.queryForObject("user_list.getUserBySn_User_id", paramMap, User_List.class);
	}

	public User_List getUserByNickname(String nickname) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("nickname", nickname);
		return dalClient.queryForObject("user_list.getUserByNickname", paramMap, User_List.class);
	}

	public User_List getUserBySn_Phone(String sn_phone) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("sn_phone", sn_phone);
		return dalClient.queryForObject("user_list.getUserBySn_Phone", paramMap, User_List.class);
	}

	public User_List getUserBySn_email(String sn_email) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("sn_email", sn_email);
		return dalClient.queryForObject("user_list.getUserBySn_email", paramMap, User_List.class);
	}

	public User_List getUserBySn_Username(String sn_username) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("sn_username", sn_username);
		return dalClient.queryForObject("user_list.getUserBySn_Username", paramMap, User_List.class);
	}

	public User_List getUserBySn_Nick(String sn_nick) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("sn_nick", sn_nick);
		return dalClient.queryForObject("user_list.getUserBySn_Nick", paramMap, User_List.class);
	}

	public User_List getUserByNickExceptId(String nickname, long id) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("nickname", nickname);
		paramMap.put("id", id);
		return dalClient.queryForObject("user_list.getUserByNickExceptId", paramMap, User_List.class);
	}

	public void updateUser(User_List user_List) {
		dalClient.execute("user_list.updateUser", user_List);
	}

	public List<User_List> getAllUser() {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		return dalClient.queryForList("user_list.getAllUser", paramMap, User_List.class);
	}

	@Override
	public void decrementTotalScore(long id, long decrementScore) {
		Map<String, Long> paramMap = new HashMap<String, Long>();
		paramMap.put("id", id);
		paramMap.put("decrementScore", decrementScore);
		int result = dalClient.execute("user_list.decrementTotalScore", paramMap);
		System.out.println(result);
	}

	@Override
	public List<User_List> getAllUserByPage(int start, int size) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("start", start);
		paramMap.put("size", size);
		return dalClient.queryForList("user_list.getAllUserByPage", paramMap, User_List.class);
	}

	@Override
	public int updateTotalScoreById(long id, long totalScore) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("id", id);
		paramMap.put("totalScore", totalScore);
		return dalClient.execute("user_list.updateTotalScoreById", paramMap);
	}

	@Override
	public int deleteUserById(long id) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("id", id);
		return dalClient.execute("user_list.deleteUserById", paramMap);
	}

	@Override
	public int updateUserSnInfoById(User_List user) {
		return dalClient.execute("user_list.updateUserSnInfoById", user);
	}

	@Override
	public int updateUserForAdmin(User_List user_List) {
		return dalClient.execute("user_list.updateUserForAdmin", user_List);
	}

	@Override
	public User_List getByMap(Map<String, Object> paramMap) {
		return dalClient.queryForObject("user_list.getByMap", paramMap, User_List.class);
	}
}
