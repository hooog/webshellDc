package com.enation.app.shop.component.payment.plugin.alipay.sdk34.api.response;


import com.enation.app.shop.component.payment.plugin.alipay.sdk34.api.AlipayResponse;

/**
 * ALIPAY API: alipay.open.public.menu.modify response.
 * 
 * @author auto create
 * @since 1.0, 2017-05-25 11:40:42
 */
public class AlipayOpenPublicMenuModifyResponse extends AlipayResponse {

	private static final long serialVersionUID = 6319949414878456492L;

	

	

}
