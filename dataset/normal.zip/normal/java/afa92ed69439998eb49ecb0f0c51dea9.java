/**
 * 封装了Pinyin4j的引擎。
 *
 * <p>
 * pinyin4j(http://sourceforge.net/projects/pinyin4j)封装。
 * </p>
 *
 * <p>
 * 引入：
 * <pre>
 * &lt;dependency&gt;
 *     &lt;groupId&gt;com.belerweb&lt;/groupId&gt;
 *     &lt;artifactId&gt;pinyin4j&lt;/artifactId&gt;
 *     &lt;version&gt;2.5.1&lt;/version&gt;
 * &lt;/dependency&gt;
 * </pre>
 *
 * @author looly
 */
package cn.hutool.extra.pinyin.engine.pinyin4j;