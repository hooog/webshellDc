package com.enation.app.shop.component.payment.plugin.alipay.sdk34.api.response;


import com.enation.app.shop.component.payment.plugin.alipay.sdk34.api.AlipayResponse;

/**
 * ALIPAY API: alipay.daowei.order.sp.modify response.
 * 
 * @author auto create
 * @since 1.0, 2017-03-20 14:01:51
 */
public class AlipayDaoweiOrderSpModifyResponse extends AlipayResponse {

	private static final long serialVersionUID = 4563287118862628196L;

	

	

}
