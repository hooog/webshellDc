import javax.naming.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.sql.DataSource;
import java.io.IOException;
import java.sql.*;

public class GetConnectionByDataSource extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=UTF-8");
        try {
            InitialContext initContext = new InitialContext();//获取初始化的上下文对象
            //获取配置的数据源的名称的相应数据源对象
            DataSource ds = (DataSource) initContext.lookup("java:/comp/env/jdbc/09");
            Connection c = ds.getConnection();//获取数据源连接
            if (c != null) {
                System.out.println("连接成功");
                c.close();
            } else
                System.out.println("链接失败");
        } catch (NamingException | SQLException e) {
            e.printStackTrace();
        }
    }
}
