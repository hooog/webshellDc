/*
 * Copyright (C), 2002-2015, 苏宁易购电子商务有限公司
 * FileName: Score_Consume_ListDaoImpl.java
 * Author:   15071335
 * Date:     2015年8月5日 下午7:28:05
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.suning.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.suning.dao.IScore_Consume_ListDao;
import com.suning.framework.dal.client.support.DefaultDalClient;
import com.suning.pojo.Score_Consume_List;

/**
 * 〈一句话功能简述〉<br>
 * 〈功能详细描述〉
 *
 * @author 15071335
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class Score_Consume_ListDaoImpl implements IScore_Consume_ListDao {
    private static final Logger logger = LoggerFactory.getLogger("Score_Consume_ListDaoImpl");

    @Autowired
    private DefaultDalClient dalClient;

    public DefaultDalClient getDalClient() {
        return dalClient;
    }

    public void setDalClient(DefaultDalClient dalClient) {
        this.dalClient = dalClient;
    }

    public List<Score_Consume_List> getAllScoreConsumeByMap(Map<String, Object> paramMap) {
        return dalClient.queryForList("score_consume_list.getAllScoreConsumeByMap", paramMap, Score_Consume_List.class);
    }

    public String getCustno(long id)
    {
        Map<String, Object> paramMap=new HashMap<String,Object>();
        paramMap.put("id",id);
        return dalClient.queryForObject("score_consume_list.getCustno",paramMap,String.class);
    }

    @Override
    public long getSumConsumedScoreByUserId(Map<String, Object> paramMap) {
        long score = 0;
        try {
            score = dalClient.queryForObject("score_consume_list.getSumConsumedScoreByUserId", paramMap, Long.class);
        } catch (Exception e) {
        	logger.debug("Exception",e);
            score = 0;
        }
        return score;
    }

    @Override
    public int insertConsumedScoreByMap(Map<String, Object> paramMap) {
        return dalClient.execute("score_consume_list.insertConsumedScoreByMap", paramMap);
    }

    @Override
    public int deleteConsumedScoreByMap(Map<String, Object> paramMap) {
        return dalClient.execute("score_consume_list.deleteConsumedScoreByMap", paramMap);
    }

    @Override
    public int updateConsumedScoreByMap(Map<String, Object> paramMap) {
        return dalClient.execute("score_consume_list.updateConsumedScoreByMap", paramMap);
    }
}
