package cn.hutool.json.test.bean;

import cn.hutool.json.JSONObject;

public class JSONBean {

	private int code;
	private JSONObject data;
	
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public JSONObject getData() {
		return data;
	}
	public void setData(JSONObject data) {
		this.data = data;
	}
}
