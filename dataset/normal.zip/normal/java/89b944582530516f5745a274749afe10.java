package com.suning.util;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ConcurrentUtil {
	private static final Logger logger = LoggerFactory.getLogger("ConcurrentUtil");
	private static final ExecutorService service = Executors.newFixedThreadPool(5);
	public static void call(Runnable runable) {
	    	  service.execute(runable);
	}

	public static void execSendMessage(final String sn_user_id, final String title, final String content,final Integer systemId,final CaseTaskRun caseTaskRun) {
		Runnable run = new Runnable() {
			@Override
			public void run() {
				try {
					Thread.sleep(1000);			
				} catch (InterruptedException e) {
					logger.debug("runCommand error:" + e.getMessage(), e);
				}
				caseTaskRun.processMessage(sn_user_id,title, content,systemId);
			}
		};
		call(run);
	}
}
