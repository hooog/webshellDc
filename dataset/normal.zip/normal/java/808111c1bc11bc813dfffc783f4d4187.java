package com.enation.app.shop.component.payment.plugin.alipay.sdk34.api.response;


import com.enation.app.shop.component.payment.plugin.alipay.sdk34.api.AlipayResponse;

/**
 * ALIPAY API: koubei.retail.shopitem.modify response.
 * 
 * @author auto create
 * @since 1.0, 2017-04-14 18:08:34
 */
public class KoubeiRetailShopitemModifyResponse extends AlipayResponse {

	private static final long serialVersionUID = 3187466353612337833L;

	

	

}
