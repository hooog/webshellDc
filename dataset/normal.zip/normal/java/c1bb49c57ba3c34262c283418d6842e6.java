package com.enation.app.shop.component.payment.plugin.alipay.sdk34.api.domain;

import com.enation.app.shop.component.payment.plugin.alipay.sdk34.api.AlipayObject;
import com.enation.app.shop.component.payment.plugin.alipay.sdk34.api.internal.mapping.ApiField;

/**
 * 模型查询参数
 *
 * @author auto create
 * @since 1.0, 2017-04-27 14:36:26
 */
public class ModelQueryParam extends AlipayObject {

	private static final long serialVersionUID = 5894697895679365952L;

	/**
	 * 条件查询参数
	 */
	@ApiField("key")
	private String key;

	/**
	 * 操作计算符，目前仅支持EQ
	 */
	@ApiField("operate")
	private String operate;

	/**
	 * 查询参数值
	 */
	@ApiField("value")
	private String value;

	public String getKey() {
		return this.key;
	}
	public void setKey(String key) {
		this.key = key;
	}

	public String getOperate() {
		return this.operate;
	}
	public void setOperate(String operate) {
		this.operate = operate;
	}

	public String getValue() {
		return this.value;
	}
	public void setValue(String value) {
		this.value = value;
	}

}
