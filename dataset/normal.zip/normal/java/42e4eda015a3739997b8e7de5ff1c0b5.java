/**
 * Script模块主要针对Java的javax.script封装，可以运行Javascript脚本。
 * 
 * @author looly
 *
 */
package cn.hutool.script;