package com.jspxcms.ext.repository.plus;

public interface QuestionOptionDaoPlus {

}
