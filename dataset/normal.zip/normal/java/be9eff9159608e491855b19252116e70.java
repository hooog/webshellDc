package me.chanjar.weixin.mp.bean.membercard;

import lombok.Data;

/**
 * @author yqx
 * @date 2018/9/19
 */
@Data
public class ActivatePluginParamResult {

  private int errcode;

  private String errmsg;

  private String url;

}
