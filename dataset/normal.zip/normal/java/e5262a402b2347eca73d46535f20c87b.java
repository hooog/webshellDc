package com.itheima.logaspect;

import com.itheima.domain.Log;
import com.itheima.domain.User;
import com.itheima.service.LogService;
import com.sun.tracing.dtrace.Attributes;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ControllerAdvice;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.zip.DataFormatException;

@Aspect
@Component
public class LogAop {

    @Autowired
    private HttpServletRequest request;

    @Autowired
    private LogService logService;
    /*
     *
     * 环绕通知 ProceedingJoinPoint(记录某些方法)
     * 执行proceed方法的作用是让目标方法执行，
     * 这也是环绕通知和前置、后置通知方法的一个最大区别。
     * 简单理解，环绕通知=前置+目标方法执行+后置通知，
     * proceed方法就是用于启动目标方法执行的。
     *
     * */
    @Around("execution(* com.itheima.controller.*.*(..))")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        /*开始时间*/
        Date start = new Date();
        /*用于启动目标方法执行*/
        Object proceed = joinPoint.proceed();
        /*获取开始到结束使用时间*/
        long cost = new Date().getTime() - start.getTime();
        /*获取实体类的名称*/
        String className = joinPoint.getTarget().getClass().getName();
        /*获取方法名称*/
        String methodName = joinPoint.getSignature().getName();
        /*从session域中获取用户*/
        User user = (User) request.getSession().getAttribute("user");
        String userName="";
        if (user!=null){
             userName = user.getName();
        }else {
             userName = request.getParameter("name" + "[登录失败]");
        }
        /*将数据存入log中*/
        Log log = new Log();
        log.setUrl("[类名]"+className+"[方法名]"+methodName);
        log.setName(userName);
        log.setCost(cost);
        log.setTime(new Date());
        logService.insert(log);
        return proceed;
    }

}
