/*
 * Copyright (C), 2002-2016, 苏宁易购电子商务有限公司
 * FileName: UserLocker.java
 * Author:   15071335
 * Date:     2016年9月1日 下午3:28:51
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.suning.util;

import java.util.Set;

import org.eclipse.jetty.util.ConcurrentHashSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 〈一句话功能简述〉<br>
 * 〈功能详细描述〉
 *
 * @author 15071335
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class UserLocker {
    private static final Logger logger = LoggerFactory.getLogger(UserLocker.class);
    private static Set<Long> lockerSet = new ConcurrentHashSet<Long>();

    public static void addLocker(long userId) {
        if (!lockerSet.contains(userId)) {
            // 没有加锁
            lockerSet.add(userId);
        } else {
            // 已经加锁了
            while (lockerSet.contains(userId)) {
                // 循环等锁
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    logger.debug(e.getMessage(),e);
                }
            }
            lockerSet.add(userId);
        }
    }

    public static boolean unLocker(long userId) {
        return lockerSet.remove(userId);
    }
}
