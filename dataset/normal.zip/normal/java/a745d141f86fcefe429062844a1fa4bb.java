package com.suning.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.suning.framework.image.service.ImageServiceClientImpl;
import com.suning.framework.image.service.ImageServiceException;
import com.suning.pojo.Element_List;
import com.suning.pojo.Special_Area_List;
import com.suning.service.IElement_ListService;
import com.suning.service.SpecialAreaService;
import com.suning.util.AESHelper;
import com.suning.util.ScmConfigurationUtil;

@Controller
public class ElementController {
    private static final Logger logger = LoggerFactory.getLogger(ElementController.class);
    @Autowired
    IElement_ListService elementService;
    @Autowired
    SpecialAreaService specialAreaService;

    @RequestMapping("/admin/elementList.do")
    public ModelAndView showElementList(HttpServletRequest request, HttpServletResponse response) {

        double totalElement = elementService.queryAllCountElement();
        int pageElementSize = 4;
        int totalElementPageSize = (int) Math.ceil(totalElement / pageElementSize);

        int page;
        try {
            page = request.getParameter("page") == null ? 1 : Integer.parseInt(request.getParameter("page"));
        } catch (NumberFormatException e) {
            page = 1;
        }
        if (page < 1 || totalElementPageSize == 0) {
            page = 1;
        } else if (page > totalElementPageSize) {
            page = totalElementPageSize;
        }

        List<Element_List> elementList = elementService.queryElementByPage(page, pageElementSize);

        ModelAndView mva = new ModelAndView();
        mva.addObject("page", page);
        mva.addObject("pageSize", pageElementSize);
        mva.addObject("totalPageSize", totalElementPageSize);
        mva.addObject("total", (int) totalElement);
        mva.addObject("elementList", elementList);
        mva.setViewName("elementList.jsp");

        return mva;
    }

    @RequestMapping("/admin/addElement.do")
    public ModelAndView addElement(HttpServletRequest req, HttpServletResponse res) {
        ModelAndView mv = new ModelAndView();
        List<Special_Area_List> selectList = specialAreaService.querySpecialArea();
        mv.addObject("selectList", selectList);
        mv.setViewName("addElement.jsp");
        return mv;
    }

    @RequestMapping("/admin/insertElement.do")
    public String insertSpecialArea(HttpServletRequest req, HttpServletResponse res) {
        String delete_flag = req.getParameter("delete_flag");
        String name = req.getParameter("name");
        String tag = req.getParameter("area_tag");
        String url = req.getParameter("pic_url");
        String content = req.getParameter("content");
        String text = req.getParameter("des_text");

        Element_List elList = new Element_List();
        elList.setArea_tag(tag);
        elList.setName(name);
        elList.setContent(content);
        elList.setPic_url(url);
        elList.setText(text);
        elList.setDelete_flag(delete_flag.charAt(0));

        elementService.addElement(elList);
        return "redirect:elementList.do";
    }

    @RequestMapping("/admin/deleteElement.do")
    public void deleteElement(HttpServletRequest req, HttpServletResponse res) {
        String param = req.getParameter("param");
        String[] ids = param.split(",");
        elementService.deleteElement(ids);
        try {
            res.getWriter().write("0");
        } catch (IOException e) {
        logger.debug(e.getMessage(),e);
        }
    }

    @RequestMapping("/admin/updateElement.do")
    public ModelAndView updateElement(HttpServletRequest req, HttpServletResponse res) {
        String id = req.getParameter("id");
        ModelAndView mv = new ModelAndView();
        Element_List element = elementService.queryOne(Integer.parseInt(id));
        List<Special_Area_List> selectList = specialAreaService.querySpecialArea();
        mv.addObject("selectList", selectList);
        mv.addObject("element", element);
        mv.setViewName("updateElement.jsp");
        return mv;
    }

    @RequestMapping("/admin/modifyElement.do")
    public String modifyElement(HttpServletRequest req, HttpServletResponse res) {

        String id = req.getParameter("id");
        String area_tag = req.getParameter("area_tag");
        String name = req.getParameter("name");
        String content = req.getParameter("content");
        String text = req.getParameter("des_text");
        String pic_url = req.getParameter("pic_url");

        Element_List list = new Element_List();
        list.setId(Long.parseLong(id));
        list.setArea_tag(area_tag);
        list.setContent(content);
        list.setName(name);
        list.setPic_url(pic_url);
        list.setText(text);

        elementService.updateElement(list);
        try {
            res.getWriter().write("0");
        } catch (IOException e) {
            logger.debug(e.getMessage(),e);
        }
        return "redirect:elementList.do";
    }

    @RequestMapping("/admin/changeElementState.do")
    public void enableBulletin(HttpServletRequest req, HttpServletResponse res) {
        String id = req.getParameter("id");
        String flag = req.getParameter("flag");

        elementService.changeState(Integer.parseInt(id), flag);
        try {
            res.getWriter().write("0");
        } catch (IOException e) {
            logger.debug(e.getMessage(),e);
        }

    }

    @RequestMapping("/admin/uploadFile.do")
    public void uploadFile(HttpServletRequest req, HttpServletResponse res) {

        // 转型为MultipartHttpRequest：
        MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) req;
        // 获得文件：
        MultipartFile file = multipartRequest.getFile("file");

        String overId = null;

        InputStream in = null;

        String path = null;
        try {
            in = file.getInputStream();
        } catch (IOException e) {
            logger.debug(e.getMessage(),e);
        }
        ImageServiceClientImpl imageServiceClient = new ImageServiceClientImpl("uimg");

        String imgurl = ScmConfigurationUtil.getImgurl();
        String uimg = ScmConfigurationUtil.getuimg();
        String uimgCode = ScmConfigurationUtil.getuimgCode();
        String folder = ScmConfigurationUtil.getuimgLeakFolder();
        String uimgType = ScmConfigurationUtil.getuimgType();

        try {
            // overId = imageServiceClient.uploadFile("b2c", "test", in, "test123");
        	Date now = new Date();
            String overName = AESHelper.encrypt(now.getTime()+""+AESHelper.generateWord());//加密  
            overId=overName;
           imageServiceClient.uploadFile(uimgCode, folder,overId,null, in, uimgType);
        } catch (ImageServiceException e) {
            logger.debug(e.getMessage(),e);
        }
        // path = "http://10.19.250.38:81/uimg/b2c/test/" + overId + ".jpg";
        path = imgurl + uimg + "/" + uimgCode + "/" + folder + "/" + overId + ".jpg";

        try {
            res.getWriter().write(path);
        } catch (IOException e) {
            logger.debug(e.getMessage(),e);
        }
    }

}
