/**
 * jboss-logging实现
 * 
 * @author looly
 *
 */
package cn.hutool.log.dialect.jboss;