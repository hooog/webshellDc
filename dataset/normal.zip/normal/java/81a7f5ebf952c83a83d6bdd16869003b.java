/*
 * Copyright (C), 2002-2016, 苏宁易购电子商务有限公司
 * FileName: ItpSystemServiceImpl.java
 * Author:   15071335
 * Date:     2016年11月17日 上午9:47:16
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.suning.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.suning.dao.IItpSystemDao;
import com.suning.dao.ISsrcConfDao;
import com.suning.pojo.ItpChildSystem;
import com.suning.pojo.ItpParentSystem;
import com.suning.pojo.Itp_System;
import com.suning.pojo.Ssrc_Conf;
import com.suning.pojo.System_List;
import com.suning.service.IItpSystemService;
import com.suning.service.ISystem_ListService;
import com.suning.util.SsrcUtil;

/**
 * 〈一句话功能简述〉<br>
 * 〈功能详细描述〉
 *
 * @author 15071335
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
@Service
public class ItpSystemServiceImpl implements IItpSystemService {

    private static final Logger logger = LoggerFactory.getLogger("ItpSystemServiceImpl");

    @Autowired
    IItpSystemDao itpSystemDaoImpl;
    @Autowired
    ISystem_ListService system_ListServiceImpl;
    @Autowired
    ISsrcConfDao ssrcConfDaoImpl;

    @Override
    public int processJMSMessage(String xml) {
        int result = 0;
        logger.info("即将要解析的jms消息为:" + xml);
        try {
            Document dom = DocumentHelper.parseText(xml);
            if (null != dom) {
                Element serviceCodeEle = (Element) dom.selectSingleNode("//ServiceCode");
                Element operationEle = (Element) dom.selectSingleNode("//Operation");
                if (null != serviceCodeEle && serviceCodeEle.getText().equals("ITProjectOperationMgmt_SSRC")

                        && null != operationEle && operationEle.getText().equals("syncSystemBD")) {
                    parseJMSDom(dom);
                } else {
                    logger.warn("jms消息里的ServiceCode!=ITProjectOperationMgmt并且Operation!=syncSystemBD,停止解析");
                }
            } else {
                logger.debug("解析dom出错了,dom为null");
            }
        } catch (Exception e) {
//            ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream();
            logger.debug("Exception",e);
        }

        return result;
    }

    @Override
    public int parseJMSDom(Document dom) {
        int result = 0;

        String action = dom.selectSingleNode("//action") == null ? "" : dom.selectSingleNode("//action").getText();
        //主系统id
        String systemId = dom.selectSingleNode("//systemId") == null ? ""
                : dom.selectSingleNode("//systemId").getText();
        //子系统id
        String systemUid = dom.selectSingleNode("//systemUid") == null ? ""
                : dom.selectSingleNode("//systemUid").getText();
        // 系统中文全称
//        String systemChName = dom.selectSingleNode("//systemChName") == null ? ""
//                : dom.selectSingleNode("//systemChName").getText();
        //系统英文简称
//        String systemEhShortName = dom.selectSingleNode("//systemEhShortName") == null ? ""
//                : dom.selectSingleNode("//systemEhShortName").getText();
        //系统全称（中文全称+英文简称）
//       String system_full_name = systemChName + "(" + systemEhShortName + ")";

        //子系统中文全称
        String sndSystemChName = dom.selectSingleNode("//sndSystemChName") == null ? ""
                : dom.selectSingleNode("//sndSystemChName").getText();
        //子系统英文简称
        String sndSystemEhShortName = dom.selectSingleNode("//sndSystemEhShortName") == null ? ""
                : dom.selectSingleNode("//sndSystemEhShortName").getText();
        //系统英文全称
//        String systemEhName = dom.selectSingleNode("//systemEhName") == null ? ""
//                : dom.selectSingleNode("//systemEhName").getText();
        //系统管理员
//        String systemConfigAdmin = dom.selectSingleNode("//systemConfigAdmin") == null ? ""
//                : dom.selectSingleNode("//systemConfigAdmin").getText();
        //归属一级中心
        String firstCenterName = dom.selectSingleNode("//firstCenterName") == null ? ""
                : dom.selectSingleNode("//firstCenterName").getText();
        //归属二级中心
        String secondCenter = dom.selectSingleNode("//secondCenter") == null ? ""
                : dom.selectSingleNode("//secondCenter").getText();
        //技术总监
        String techDirector = dom.selectSingleNode("//techDirector") == null ? ""
                : dom.selectSingleNode("//techDirector").getText();
        //产品总监
//        String productDirector = dom.selectSingleNode("//productDirector") == null ? ""
//                : dom.selectSingleNode("//productDirector").getText();
        //技术负责人
        String techManger = dom.selectSingleNode("//techManger") == null ? ""
                : dom.selectSingleNode("//techManger").getText();
        //产品负责人
//        String productManger = dom.selectSingleNode("//productManger") == null ? ""
//                : dom.selectSingleNode("//productManger").getText();
        //系统等级
        String systemGrade = dom.selectSingleNode("//systemGrade") == null ? ""
                : dom.selectSingleNode("//systemGrade").getText();
        //操作对象标识
        String actionTarget = dom.selectSingleNode("//actionTarget") == null ? ""
                : dom.selectSingleNode("//actionTarget").getText();
        //子系统有效性
        //      String child_system_validity = "有效";
//        //主系统有效性
//        String system_validity = "有效";
//        //ea建议主系统等级
//        String ea_system_level = "";
        //ea建议子系统等级
        // String ea_child_system_level = "";
        //客户编码
//        String customer_code = "";
//        //是否为sap
//        String is_sap = "";
//        //系统类型
//        String system_type = "";
        if (action.equals("A")) {
            // 新增
            if (actionTarget.equals("M")) {
                // 新增主系统
                if (!StringUtils.isEmpty(systemId)) {

                    logger.info("主系统新增暂时不操作");
                } else {
                    logger.info("没有找到systemId字段,不进行主系统新增操作");
                }

            } else if (actionTarget.equals("S")) {
                // 新增子系统
                if (!StringUtils.isEmpty(systemUid)) {

                    System_List systemList = new System_List();
                    String dutyUserId = SsrcUtil.splitUserId(techManger);
                    String dutyUserName = SsrcUtil.splitUserName(techManger);
                    String bossUserId = SsrcUtil.splitUserId(techDirector);
                    String bossUserName = SsrcUtil.splitUserName(techDirector);
                    String sysRadio = null;
                    systemList.setItp_child_id(systemUid);
                    systemList.setName(sndSystemChName + "(" + sndSystemEhShortName + ")");
                    systemList.setFirst_center_name(firstCenterName);
                    systemList.setSecond_center_name(secondCenter);
                    systemList.setDuty_sn_user_id(dutyUserId);
                    systemList.setDuty_sn_user_name(dutyUserName);
                    systemList.setDuty_sn_boss_id(bossUserId);
                    systemList.setDuty_sn_boss_name(bossUserName);
                    systemList.setSystem_level(systemGrade);

                    if ("一级".equals(systemGrade)) {
                        sysRadio = "10";
                    } else if ("二级".equals(systemGrade)) {
                        sysRadio = "5";
                    } else {
                        sysRadio = "1";
                    }
                    systemList.setSystem_radio(sysRadio);
                    //标识是新增的itp系统信息
                    systemList.setCustom1("1");
                    system_ListServiceImpl.insertSystem(systemList);

                } else {
                    logger.info("没有找到systemUid字段,不进行子系统新增操作");
                }

            } else {
                logger.warn("不进行入库,因为actionTarget字段不为M也不为S");
            }

        } else if (action.equals("U")) {
            // 修改
            if (actionTarget.equals("M")) {
                // 操作主系统
                if (!StringUtils.isEmpty(systemId)) {

//                	ItpParentSystem itpParentSystem = new ItpParentSystem();
//					itpParentSystem.setParent_system_id(systemId);
//					itpParentSystem.setSystem_full_name(system_full_name);
//					itpParentSystem.setParent_system_chinese_name(systemChName);
//					itpParentSystem.setParent_system_english_name(systemEhName);
//					itpParentSystem.setParent_system_english_simple_name(systemEhShortName);
//					itpParentSystem.setParent_system_level(systemGrade);
//					
//					result = updateParentSystem(itpParentSystem);
                } else {
                    logger.warn("没有找到systemId字段,不进行主系统更新操作");
                }

            } else if (actionTarget.equals("S")) {
                // 操作子系统
                if (!StringUtils.isEmpty(systemUid)) {

                    System_List system_List = new System_List();
                    String dutyUserId = SsrcUtil.splitUserId(techManger);
                    String dutyUserName = SsrcUtil.splitUserName(techManger);
                    String bossUserId = SsrcUtil.splitUserId(techDirector);
                    String bossUserName = SsrcUtil.splitUserName(techDirector);
                    String sysRadio = null;
                    system_List.setItp_child_id(systemUid);
                    system_List.setName(sndSystemChName + "(" + sndSystemEhShortName + ")");
                    system_List.setFirst_center_name(firstCenterName);
                    system_List.setSecond_center_name(secondCenter);
                    system_List.setDuty_sn_user_id(dutyUserId);
                    system_List.setDuty_sn_user_name(dutyUserName);
                    system_List.setDuty_sn_boss_id(bossUserId);
                    system_List.setDuty_sn_boss_name(bossUserName);
                    system_List.setSystem_level(systemGrade);

                    if ("一级".equals(systemGrade)) {
                        sysRadio = "10";
                    } else if ("二级".equals(systemGrade)) {
                        sysRadio = "5";
                    } else {
                        sysRadio = "1";
                    }
                    system_List.setSystem_radio(sysRadio);

                    try {

                        Map<String, Object> params = new HashMap<String, Object>();
                        params.put("name", "itp_auto_update");
                        Ssrc_Conf conf = ssrcConfDaoImpl.getByMap(params);
                        if(conf!=null) {
                            if (conf.getValue().equals("1") || conf.getValue().equals("2"))//开始自动更新1_只更新 2_更新加新增
                            {

                                int rr = system_ListServiceImpl.updateSystem_List_Itp(system_List);
                                if (rr == 0) {
                                    if("2".equals(conf.getValue())) {
                                        system_List.setCustom1("1");
                                        system_ListServiceImpl.insertSystem(system_List);
                                    }
                                }
                            }

                        }
                    }catch (Exception e)
                    {

                        logger.debug("同步itp数据发生2=="+system_List.getItp_child_id()+","+system_List.getName(),e);
                    }
                } else {
                    logger.warn("没有找到systemUid字段,不进行子系统更新操作");
                }

            }
            result = 1;
        } else if (action.equals("D")) {

            if (actionTarget.equals("S")){

                try {
                    Map<String, Object> params = new HashMap<String, Object>();
                    params.put("name", "itp_auto_delete");
                    Ssrc_Conf conf = ssrcConfDaoImpl.getByMap(params);
                    if (conf != null && conf.getValue().equals("1"))//开始自动删除
                    {
                        if (!StringUtils.isEmpty(systemUid)) {
                            int r = system_ListServiceImpl.deleteSystemByItp(systemUid);
                            logger.info("同步失效itp数据------itp_child_id=" + systemUid + "条数=" + r);

                        }
                    }
                }catch (Exception e)
                {
                   logger.debug("同步失效itp发生2",e);
                }


            }



            // 置为无效

            result = 1;
        } else {
            logger.warn("解析itp jms消息失败,未识别的action:" + action);
        }
        return result;
    }

    @Override
    public int insert(String system_id, String chinese_full_name, String english_full_name, String english_simple_name,
                      String system_full_name, String child_system_id, String child_system_chinese_name,
                      String system_english_simple_name, String center_level1, String center_level2, String technical_director,
                      String product_director, String technical_duty, String product_duty, String system_admin,
                      String customer_code, String is_sap, String system_level, String system_type, String child_system_validity,
                      String system_validity, String child_system_level, String ea_system_level, String ea_child_system_level) {
        Map<String, Object> paramItpMap = new HashMap<String, Object>();
        paramItpMap.put("system_id", system_id);
        paramItpMap.put("chinese_full_name", chinese_full_name);
        paramItpMap.put("english_full_name", english_full_name);
        paramItpMap.put("english_simple_name", english_simple_name);
        paramItpMap.put("system_full_name", system_full_name);
        paramItpMap.put("child_system_id", child_system_id);
        paramItpMap.put("child_system_chinese_name", child_system_chinese_name);
        paramItpMap.put("system_english_simple_name", system_english_simple_name);
        paramItpMap.put("center_level1", center_level1);
        paramItpMap.put("center_level2", center_level2);
        paramItpMap.put("technical_director", technical_director);
        paramItpMap.put("product_director", product_director);
        paramItpMap.put("technical_duty", technical_duty);
        paramItpMap.put("product_duty", product_duty);
        paramItpMap.put("system_admin", system_admin);
        paramItpMap.put("customer_code", customer_code);
        paramItpMap.put("is_sap", is_sap);
        paramItpMap.put("system_level", system_level);
        paramItpMap.put("system_type", system_type);
        paramItpMap.put("child_system_validity", child_system_validity);
        paramItpMap.put("system_validity", system_validity);
        paramItpMap.put("child_system_level", child_system_level);
        paramItpMap.put("ea_system_level", ea_system_level);
        paramItpMap.put("ea_child_system_level", ea_child_system_level);
        return itpSystemDaoImpl.insertByMap(paramItpMap);
    }

    @Override
    public int update(String system_id, String chinese_full_name, String english_full_name, String english_simple_name,
                      String system_full_name, String child_system_id, String child_system_chinese_name,
                      String system_english_simple_name, String center_level1, String center_level2, String technical_director,
                      String product_director, String technical_duty, String product_duty, String system_admin,
                      String customer_code, String is_sap, String system_level, String system_type, String child_system_validity,
                      String system_validity, String child_system_level, String ea_system_level, String ea_child_system_level) {
        Map<String, Object> paramUpateMap = new HashMap<String, Object>();
        paramUpateMap.put("system_id", system_id);
        paramUpateMap.put("chinese_full_name", chinese_full_name);
        paramUpateMap.put("english_full_name", english_full_name);
        paramUpateMap.put("english_simple_name", english_simple_name);
        paramUpateMap.put("system_full_name", system_full_name);
        paramUpateMap.put("child_system_id", child_system_id);
        paramUpateMap.put("child_system_chinese_name", child_system_chinese_name);
        paramUpateMap.put("system_english_simple_name", system_english_simple_name);
        paramUpateMap.put("center_level1", center_level1);
        paramUpateMap.put("center_level2", center_level2);
        paramUpateMap.put("technical_director", technical_director);
        paramUpateMap.put("product_director", product_director);
        paramUpateMap.put("technical_duty", technical_duty);
        paramUpateMap.put("product_duty", product_duty);
        paramUpateMap.put("system_admin", system_admin);
        paramUpateMap.put("customer_code", customer_code);
        paramUpateMap.put("is_sap", is_sap);
        paramUpateMap.put("system_level", system_level);
        paramUpateMap.put("system_type", system_type);
        paramUpateMap.put("child_system_validity", child_system_validity);
        paramUpateMap.put("system_validity", system_validity);
        paramUpateMap.put("child_system_level", child_system_level);
        paramUpateMap.put("ea_system_level", ea_system_level);
        paramUpateMap.put("ea_child_system_level", ea_child_system_level);
        return itpSystemDaoImpl.updateByMap(paramUpateMap);
    }

    @Override
    public int updateMasterSystem(String systemId, String systemChName, String systemEhShortName, String systemEhName,
                                  String systemConfigAdmin, String firstCenterName, String techDirector, String productDirector,
                                  String techManger, String productManger, String secondCenter, String systemGrade) {
        Map<String, Object> paramSystemMap = new HashMap<String, Object>();
        paramSystemMap.put("system_id", systemId);

        paramSystemMap.put("system_id", systemChName);
        paramSystemMap.put("english_simple_name", systemEhShortName);
        paramSystemMap.put("english_full_name", systemEhName);
        paramSystemMap.put("system_admin", systemConfigAdmin);
        paramSystemMap.put("center_level1", firstCenterName);
        paramSystemMap.put("technical_director", techDirector);
        paramSystemMap.put("product_director", productDirector);
        paramSystemMap.put("technical_duty", techManger);
        paramSystemMap.put("product_duty", productManger);
        paramSystemMap.put("center_level2", secondCenter);
        paramSystemMap.put("system_level", systemGrade);
        return itpSystemDaoImpl.updateMasterSystem(paramSystemMap);
    }

    @Override
    public int updateSecondSystem(String systemUid, String sndSystemChName, String sndSystemEhShortName) {
        Map<String, Object> paramSecondMap = new HashMap<String, Object>();
        paramSecondMap.put("child_system_id", systemUid);

        paramSecondMap.put("child_system_chinese_name", sndSystemChName);
        paramSecondMap.put("system_english_simple_name", sndSystemEhShortName);
        return itpSystemDaoImpl.updateSalveSystem(paramSecondMap);
    }

    @Override
    public Itp_System getSecondSystem(String systemUid, String sndSystemEhShortName) {
        Map<String, Object> paramSecondMap = new HashMap<String, Object>();
        paramSecondMap.put("child_system_id", systemUid);
        paramSecondMap.put("system_english_simple_name", sndSystemEhShortName);
        return itpSystemDaoImpl.getByMap(paramSecondMap);
    }

    @Override
    public List<Itp_System> getAll() {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        return itpSystemDaoImpl.getListByMap(paramMap);
    }

    @Override
    public List<Itp_System> searchSecondSystem(String name) {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("name", name);
        return itpSystemDaoImpl.searchSecondSystem(paramMap);
    }

    @Override
    public Itp_System getSecondSystem(String systemUid) {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("child_system_id", systemUid);
        return itpSystemDaoImpl.getByMap(paramMap);
    }

    @Override
    public long getCountForTableByParams(String searchValue) {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        if (!StringUtils.isEmpty(searchValue)) {
            paramMap.put("searchValue", searchValue);
        }
        return itpSystemDaoImpl.getCountForTableByParams(paramMap);
    }

    @Override
    public List<Itp_System> getItpForTable(int start, int length, String searchValue, String orderBy) {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("start", start);
        paramMap.put("length", length);
        if (!StringUtils.isEmpty(searchValue)) {
            paramMap.put("searchValue", searchValue);
        }
        if (!StringUtils.isEmpty(orderBy)) {
            paramMap.put("orderBy", orderBy);
        }

        return itpSystemDaoImpl.getItpForTable(paramMap);
    }

    @Override
    public int addChildSystem(ItpChildSystem itpChildSystem) {

        return itpSystemDaoImpl.addChildSystem(itpChildSystem);
    }

    @Override
    public int addParentSystem(ItpParentSystem itpParentSystem) {
        return itpSystemDaoImpl.addParentSystem(itpParentSystem);
    }

    @Override
    public boolean isParentSysExist(String parentSysEnSimpleName) {
        List<ItpParentSystem> list = itpSystemDaoImpl.isParentSysExist(parentSysEnSimpleName);
        if (list.size() == 0) {
            return false;
        }
        return true;
    }

    @Override
    public int updateParentSystem(ItpParentSystem itpParentSystem) {

        return itpSystemDaoImpl.updateParentSystem(itpParentSystem);
    }

    @Override
    public int updateChildSystem(ItpChildSystem itpChildSystem) {
        return itpSystemDaoImpl.updateChildSystem(itpChildSystem);
    }

    @Override
    public ItpChildSystem getChildSysById(String itpChildSysId) {
        return itpSystemDaoImpl.getChildSysById(itpChildSysId);
    }

    @Override
    public List<ItpChildSystem> queryAllByName(String name) {
        return itpSystemDaoImpl.queryAllByName(name);
    }

    @Override
    public int mappingItpSystem(System_List system) {
        return itpSystemDaoImpl.mappingItpSystem(system);
    }

    @Override
    public List<ItpChildSystem> getAllChildSystem() {
        return itpSystemDaoImpl.getAllChildSystem();
    }

}
