package com.enation.app.shop.component.payment.plugin.alipay.sdk34.api.response;


import com.enation.app.shop.component.payment.plugin.alipay.sdk34.api.AlipayResponse;

/**
 * ALIPAY API: alipay.eco.mycar.parking.enterinfo.sync response.
 * 
 * @author auto create
 * @since 1.0, 2016-12-22 15:57:43
 */
public class AlipayEcoMycarParkingEnterinfoSyncResponse extends AlipayResponse {

	private static final long serialVersionUID = 1867158798247314136L;

	

	

}
