package com.enation.app.shop.component.payment.plugin.alipay.sdk34.api.response;


import com.enation.app.shop.component.payment.plugin.alipay.sdk34.api.AlipayResponse;

/**
 * ALIPAY API: koubei.marketing.data.message.deliver response.
 * 
 * @author auto create
 * @since 1.0, 2016-09-09 17:44:32
 */
public class KoubeiMarketingDataMessageDeliverResponse extends AlipayResponse {

	private static final long serialVersionUID = 5679643287182698158L;

	

	

}
