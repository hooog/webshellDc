/**
 * JSON封装，基于json.org官方库改造
 * 
 * @author looly
 *
 */
package cn.hutool.json;