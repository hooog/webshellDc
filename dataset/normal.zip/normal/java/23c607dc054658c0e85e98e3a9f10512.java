package cn.hutool.poi.excel.test;

import lombok.Data;

@Data
public class OrderExcel {
	private String id;
	private String num;
	private String body;
}
