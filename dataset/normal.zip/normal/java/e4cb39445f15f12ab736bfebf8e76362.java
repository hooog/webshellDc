/**
 * Hutool对连接池的简单实现
 * 
 * @author looly
 *
 */
package cn.hutool.db.ds.pooled;