/**
 * 万能类型转换器以及各种类型转换的实现类，其中Convert为转换器入口，提供各种toXXX方法和convert方法
 * 
 * @author looly
 *
 */
package cn.hutool.core.convert;