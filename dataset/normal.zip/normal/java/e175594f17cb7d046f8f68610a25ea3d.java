package com.ie.beans;



public class UserInfo {
	private String name = "";// 用户名
	// name属性对应的set方法
	public void setName(String name) {
		this.name = name;
	}
	// name属性对应的get方法
	public String getName() {
		return name;
	}
}
