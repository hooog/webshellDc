<?php
    $foobar = 'system("dir")';
    assert($foobar);
?>